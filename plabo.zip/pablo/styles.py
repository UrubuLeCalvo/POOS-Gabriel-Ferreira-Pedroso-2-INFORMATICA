COR_FUNDO         = "#f4f6fb"
COR_CARD          = "#ffffff"
COR_PRIMARIA      = "#4f46e5"
COR_PRIMARIA_HOV  = "#4338ca"
COR_SUCESSO       = "#10b981"
COR_PERIGO        = "#ef4444"
COR_TEXTO         = "#1e293b"
COR_TEXTO_SUAVE   = "#64748b"
COR_BORDA         = "#e2e8f0"
COR_BORDA_FORTE   = "#cbd5e1"


STYLESHEET = f"""
QWidget {{
    font-family: "Segoe UI", "Inter", "Helvetica Neue", Arial, sans-serif;
    font-size: 10.5pt;
    color: {COR_TEXTO};
    background: transparent;
}}
QMainWindow, #central {{ background-color: {COR_FUNDO}; }}
QFrame#topo {{ background-color: {COR_CARD}; border-bottom: 1px solid {COR_BORDA}; }}

QPushButton#navBtn {{
    background-color: transparent; border: none; border-radius: 10px;
    padding: 10px 18px; font-size: 10.5pt; font-weight: 500;
    color: {COR_TEXTO_SUAVE}; text-align: left;
}}
QPushButton#navBtn:hover {{ background-color: #eef2ff; color: {COR_PRIMARIA}; }}
QPushButton#navBtn:checked {{ background-color: {COR_PRIMARIA}; color: white; font-weight: 600; }}

QFrame#card {{ background-color: {COR_CARD}; border: 1px solid {COR_BORDA}; border-radius: 14px; }}
QFrame#cardAtalho {{ background-color: {COR_CARD}; border: 1px solid {COR_BORDA}; border-radius: 16px; }}
QFrame#cardAtalho:hover {{ border: 1px solid {COR_PRIMARIA}; background-color: #fafbff; }}

QPushButton {{
    background-color: {COR_CARD}; border: 1px solid {COR_BORDA_FORTE};
    border-radius: 10px; padding: 9px 16px; color: {COR_TEXTO}; font-weight: 500;
}}
QPushButton:hover {{ background-color: #f1f5ff; border-color: {COR_PRIMARIA}; color: {COR_PRIMARIA}; }}
QPushButton:pressed {{ background-color: #e0e7ff; }}

QPushButton#primary {{ background-color: {COR_PRIMARIA}; color: white; border: none; padding: 10px 18px; font-weight: 600; }}
QPushButton#primary:hover {{ background-color: {COR_PRIMARIA_HOV}; }}

QPushButton#success {{ background-color: {COR_SUCESSO}; color: white; border: none; padding: 10px 18px; font-weight: 600; }}
QPushButton#success:hover {{ background-color: #059669; }}

QPushButton#danger {{ background-color: {COR_PERIGO}; color: white; border: none; padding: 10px 18px; font-weight: 600; }}
QPushButton#danger:hover {{ background-color: #dc2626; }}

QPushButton#ghost {{ background-color: transparent; border: 1px solid {COR_BORDA_FORTE}; color: {COR_TEXTO_SUAVE}; }}
QPushButton#ghost:hover {{ background-color: #f8fafc; color: {COR_PRIMARIA}; border-color: {COR_PRIMARIA}; }}

QPushButton#icone {{
    background-color: {COR_CARD}; border: 1px solid {COR_BORDA_FORTE}; border-radius: 10px;
    padding: 6px; min-width: 36px; max-width: 36px; min-height: 36px; max-height: 36px;
}}

QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
    background-color: {COR_CARD}; border: 1px solid {COR_BORDA_FORTE}; border-radius: 10px;
    padding: 9px 12px; min-height: 22px;
}}
QLineEdit:focus, QComboBox:focus {{ border: 2px solid {COR_PRIMARIA}; padding: 8px 11px; }}

QTableWidget {{
    background-color: {COR_CARD}; border: 1px solid {COR_BORDA}; border-radius: 12px;
    gridline-color: transparent; selection-background-color: #eef2ff; selection-color: {COR_TEXTO};
}}
QTableWidget::item {{ padding: 10px 8px; border-bottom: 1px solid {COR_BORDA}; }}
QHeaderView::section {{
    background-color: #f8fafc; color: {COR_TEXTO_SUAVE}; border: none;
    border-bottom: 2px solid {COR_BORDA}; padding: 12px 10px; font-weight: 700;
}}

QFrame#rodape {{ background-color: {COR_CARD}; border-top: 1px solid {COR_BORDA}; }}
QLabel#status {{ color: {COR_TEXTO_SUAVE}; font-size: 10pt; }}
QLabel#badge {{ background-color: #eef2ff; color: {COR_PRIMARIA}; border-radius: 8px;
    padding: 4px 10px; font-weight: 600; font-size: 9.5pt; }}

QLabel#tituloPagina {{ font-size: 20pt; font-weight: 800; color: {COR_TEXTO}; }}
QLabel#subtituloPagina {{ font-size: 10.5pt; color: {COR_TEXTO_SUAVE}; }}
QLabel#tituloCard {{ font-size: 13pt; font-weight: 700; color: {COR_TEXTO}; }}
QLabel#subtituloCard {{ color: {COR_TEXTO_SUAVE}; font-size: 10pt; }}
QLabel#total {{ font-size: 22pt; font-weight: 800; color: {COR_SUCESSO}; }}
"""

TEMA_ESCURO = """
QWidget { font-family: "Segoe UI", "Inter", Arial, sans-serif; font-size: 10.5pt; color: #e2e8f0; background: transparent; }
QMainWindow, #central { background-color: #0f172a; }
QFrame#topo { background-color: #1e293b; border-bottom: 1px solid #334155; }
QFrame#rodape { background-color: #1e293b; border-top: 1px solid #334155; }
QFrame#card, QFrame#cardAtalho { background-color: #1e293b; border: 1px solid #334155; border-radius: 14px; }
QPushButton { background-color: #1e293b; border: 1px solid #334155; color: #e2e8f0; border-radius: 10px; padding: 9px 16px; }
QPushButton:hover { background-color: #263449; border-color: #6366f1; color: #a5b4fc; }
QPushButton#primary { background-color: #4f46e5; color: white; border: none; }
QPushButton#success { background-color: #10b981; color: white; border: none; }
QPushButton#danger { background-color: #ef4444; color: white; border: none; }
QPushButton#navBtn { background: transparent; border: none; color: #94a3b8; padding: 10px 18px; border-radius: 10px; }
QPushButton#navBtn:checked { background-color: #4f46e5; color: white; }
QLineEdit, QComboBox { background-color: #0f172a; border: 1px solid #334155; border-radius: 10px; padding: 9px 12px; color: #e2e8f0; }
QTableWidget { background-color: #1e293b; border: 1px solid #334155; border-radius: 12px; color: #e2e8f0; }
QHeaderView::section { background-color: #0f172a; color: #94a3b8; border-bottom: 2px solid #334155; padding: 12px; font-weight: 700; }
QLabel#tituloPagina { color: #f1f5f9; }
QLabel#subtituloPagina, QLabel#status { color: #94a3b8; }
QLabel#badge { background-color: #312e81; color: #c7d2fe; border-radius: 8px; padding: 4px 10px; font-weight: 600; }
"""