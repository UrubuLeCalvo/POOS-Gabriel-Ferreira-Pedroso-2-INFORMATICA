import sys
import os
from datetime import datetime, date
import pedidos
import pedidos as pedidos_mod
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap, QIcon, QPainter
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QTableWidget, QTableWidgetItem,
    QMessageBox, QDoubleSpinBox, QSpinBox, QComboBox,
    QHeaderView, QAbstractItemView, QFrame, QStackedWidget, QButtonGroup,
    QGridLayout, QDialog, QScrollArea, QTextEdit, QFormLayout, QInputDialog
)

try:
    from pixcore import PixData, Pix
    PIX_DISPONIVEL = True
except ImportError:
    PIX_DISPONIVEL = False
    print("AVISO: 'pixcore' nao instalada. Rode: pip install pixcore")

from database import Database
from styles import STYLESHEET, TEMA_ESCURO
from icons import (
    icone_home, icone_produtos, icone_vendas, icone_historico,
    icone_dinheiro, icone_sol, icone_lua
)
from imagens import garantir_imagens, caminho_imagem
from config import carregar_config, salvar_config, pix_configurado, meu_ip
import pedidos


# =========================================================
# UTIL
# =========================================================
def svg_icon(svg_str, size=24):
    renderer = QSvgRenderer(svg_str.encode("utf-8"))
    pixmap = QPixmap(size, size); pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap); renderer.render(painter); painter.end()
    return QIcon(pixmap)


def titulo_pagina(titulo: str, subtitulo: str = "") -> QWidget:
    w = QWidget(); lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 10); lay.setSpacing(2)
    lbl = QLabel(titulo); lbl.setObjectName("tituloPagina"); lay.addWidget(lbl)
    if subtitulo:
        sub = QLabel(subtitulo); sub.setObjectName("subtituloPagina"); lay.addWidget(sub)
    return w


def msg_confirmar(parent, titulo, texto, info="", sim="Sim", nao="Nao"):
    box = QMessageBox(parent)
    box.setWindowTitle(titulo)
    box.setIcon(QMessageBox.Question)
    box.setText(texto)
    if info: box.setInformativeText(info)
    box.setStyleSheet("""
        QMessageBox { background-color: white; }
        QMessageBox QLabel { color: #1e293b; font-size: 12pt; background: transparent; }
        QMessageBox QPushButton {
            background-color: #4f46e5; color: white; border: none;
            border-radius: 8px; padding: 9px 20px; font-weight: 700; min-width: 100px;
        }
        QMessageBox QPushButton:hover { background-color: #4338ca; }
    """)
    b_sim = box.addButton(sim, QMessageBox.YesRole)
    b_nao = box.addButton(nao, QMessageBox.NoRole)
    box.setDefaultButton(b_sim); box.exec()
    return box.clickedButton() == b_sim


# =========================================================
# DIALOGO CADASTRO DE CLIENTE
# =========================================================
class DialogCadastroCliente(QDialog):
    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db; self.cliente_logado = None
        self.setWindowTitle("Criar conta - Loja Pablo")
        self.setFixedSize(400, 500); self.setModal(True)
        self._build()

    def _build(self):
        self.setStyleSheet("""
            QDialog { background: #f8fafc; }
            QLabel { background: transparent; color: #1e293b; }
            QLineEdit { background: white; border: 2px solid #e2e8f0;
                border-radius: 10px; padding: 12px 14px; font-size: 11pt; color: #1e293b; }
            QLineEdit:focus { border: 2px solid #4f46e5; }
            QPushButton#ok { background-color: #10b981; color: white; border: none;
                border-radius: 10px; padding: 14px; font-size: 12pt; font-weight: 800; }
            QPushButton#ok:hover { background-color: #059669; }
            QPushButton#cancel { background-color: white; color: #64748b;
                border: 1px solid #cbd5e1; border-radius: 10px; padding: 12px; font-weight: 600; }
            QPushButton#cancel:hover { background-color: #f1f5f9; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30); layout.setSpacing(10)

        t = QLabel("📝  Criar conta fiado"); t.setAlignment(Qt.AlignCenter)
        t.setStyleSheet("font-size: 18pt; font-weight: 900; color: #4f46e5;")
        layout.addWidget(t)
        s = QLabel("Seu limite inicial é R$ 50,00"); s.setAlignment(Qt.AlignCenter)
        s.setStyleSheet("color: #64748b; font-size: 10pt; padding-bottom: 10px;")
        layout.addWidget(s)

        layout.addWidget(QLabel("<b>Nome:</b>"))
        self.txt_nome = QLineEdit(); self.txt_nome.setPlaceholderText("Como quer ser chamado")
        layout.addWidget(self.txt_nome)

        layout.addWidget(QLabel("<b>Senha (para usar o fiado):</b>"))
        self.txt_senha = QLineEdit(); self.txt_senha.setPlaceholderText("Crie uma senha")
        self.txt_senha.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.txt_senha)

        layout.addWidget(QLabel("<b>Confirmar senha:</b>"))
        self.txt_senha2 = QLineEdit(); self.txt_senha2.setPlaceholderText("Repita a senha")
        self.txt_senha2.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.txt_senha2)
        layout.addSpacing(10)

        b = QHBoxLayout()
        ok = QPushButton("Criar conta"); ok.setObjectName("ok"); ok.setMinimumHeight(48)
        ok.clicked.connect(self._salvar)
        c = QPushButton("↩  Voltar"); c.setObjectName("cancel"); c.setMinimumHeight(48)
        c.clicked.connect(self.reject)
        b.addWidget(ok, 2); b.addWidget(c, 1)
        layout.addLayout(b)
        layout.addStretch()
        self.txt_nome.setFocus()

    def _salvar(self):
        nome = self.txt_nome.text().strip()
        s1 = self.txt_senha.text().strip()
        s2 = self.txt_senha2.text().strip()
        if not nome:
            QMessageBox.warning(self, "Erro", "Informe seu nome."); return
        if len(s1) < 3:
            QMessageBox.warning(self, "Erro", "Senha muito curta."); return
        if s1 != s2:
            QMessageBox.warning(self, "Erro", "As senhas nao conferem."); return
        try:
            self.db.adicionar_cliente(nome, "", 50.0, s1)
            self.cliente_logado = {"usuario": nome, "tipo": "cliente", "cliente_nome": nome}
            QMessageBox.information(self, "Bem-vindo!",
                f"Conta criada, {nome}!\n\nSeu limite inicial de fiado é R$ 50,00.")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha ao criar conta:\n{e}")


# =========================================================
# DIALOGO LOGIN DO FUNCIONARIO
# =========================================================
class DialogLoginFuncionario(QDialog):
    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db; self.usuario_logado = None
        self.setWindowTitle("Login de funcionário")
        self.setFixedSize(400, 420); self.setModal(True)
        self._build()

    def _build(self):
        self.setStyleSheet("""
            QDialog { background: #f8fafc; }
            QLabel { background: transparent; color: #1e293b; }
            QLineEdit { background: white; border: 2px solid #e2e8f0;
                border-radius: 10px; padding: 12px 14px; font-size: 11pt; color: #1e293b; }
            QLineEdit:focus { border: 2px solid #4f46e5; }
            QPushButton#ok { background-color: #4f46e5; color: white; border: none;
                border-radius: 10px; padding: 14px; font-size: 12pt; font-weight: 800; }
            QPushButton#ok:hover { background-color: #4338ca; }
            QPushButton#cancel { background-color: white; color: #64748b;
                border: 1px solid #cbd5e1; border-radius: 10px; padding: 12px; font-weight: 600; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30); layout.setSpacing(10)

        t = QLabel("🔒  Acesso do funcionário"); t.setAlignment(Qt.AlignCenter)
        t.setStyleSheet("font-size: 16pt; font-weight: 900; color: #4f46e5;")
        layout.addWidget(t)
        s = QLabel("Entre com admin ou vendedor"); s.setAlignment(Qt.AlignCenter)
        s.setStyleSheet("color: #64748b; font-size: 10pt; padding-bottom: 10px;")
        layout.addWidget(s)

        layout.addWidget(QLabel("<b>Usuário:</b>"))
        self.txt_u = QLineEdit(); self.txt_u.setPlaceholderText("admin ou vendedor")
        layout.addWidget(self.txt_u)

        layout.addWidget(QLabel("<b>Senha:</b>"))
        self.txt_s = QLineEdit(); self.txt_s.setPlaceholderText("Senha")
        self.txt_s.setEchoMode(QLineEdit.Password)
        self.txt_s.returnPressed.connect(self._entrar)
        layout.addWidget(self.txt_s)
        layout.addSpacing(10)

        b = QHBoxLayout()
        ok = QPushButton("Entrar"); ok.setObjectName("ok"); ok.setMinimumHeight(48)
        ok.clicked.connect(self._entrar)
        c = QPushButton("Voltar"); c.setObjectName("cancel"); c.setMinimumHeight(48)
        c.clicked.connect(self.reject)
        b.addWidget(ok, 2); b.addWidget(c, 1)
        layout.addLayout(b)
        layout.addStretch()
        self.txt_u.setFocus()

    def _entrar(self):
        u = self.db.autenticar(self.txt_u.text().strip(), self.txt_s.text().strip())
        if not u:
            QMessageBox.critical(self, "Erro", "Usuário ou senha incorretos."); return
        self.usuario_logado = {"usuario": u["usuario"], "tipo": u["tipo"], "cliente_nome": None}
        self.accept()


# =========================================================
# DIALOGO PIX
# =========================================================
class DialogPix(QDialog):
    def __init__(self, caminho_qr_code, payload, valor, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pagamento via Pix")
        self.setMinimumWidth(400); self.setModal(True)
        layout = QVBoxLayout(self); layout.setSpacing(12); layout.setContentsMargins(24, 24, 24, 24)
        t = QLabel(f"<b>Pague R$ {valor:.2f}</b>".replace(".", ","))
        t.setAlignment(Qt.AlignCenter); t.setStyleSheet("font-size: 16pt; color: #4f46e5;")
        layout.addWidget(t)
        s = QLabel("Escaneie o QR Code abaixo"); s.setAlignment(Qt.AlignCenter)
        s.setStyleSheet("color: #64748b;"); layout.addWidget(s)

        lbl_qr = QLabel(); pixmap = QPixmap(caminho_qr_code)
        if not pixmap.isNull():
            pixmap = pixmap.scaled(260, 260, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            lbl_qr.setPixmap(pixmap)
        else:
            lbl_qr.setText("(falha ao carregar QR Code)")
        lbl_qr.setAlignment(Qt.AlignCenter); layout.addWidget(lbl_qr)

        layout.addWidget(QLabel("<b>Ou copie o codigo Pix:</b>"))
        self.txt_payload = QLineEdit(payload); self.txt_payload.setReadOnly(True)
        self.txt_payload.setCursorPosition(0); layout.addWidget(self.txt_payload)

        btn_copiar = QPushButton("Copiar codigo Pix"); btn_copiar.setObjectName("primary")
        btn_copiar.clicked.connect(self._copiar); layout.addWidget(btn_copiar)
        layout.addSpacing(6)

        b = QHBoxLayout()
        p = QPushButton("Ja recebi o pagamento"); p.setObjectName("success"); p.clicked.connect(self.accept)
        c = QPushButton("Cancelar"); c.setObjectName("danger"); c.clicked.connect(self.reject)
        b.addWidget(p); b.addWidget(c); layout.addLayout(b)

    def _copiar(self):
        QApplication.clipboard().setText(self.txt_payload.text())
        QMessageBox.information(self, "Copiado", "Codigo Pix copiado!")


# =========================================================
# DIALOGO NOVO FIADO
# =========================================================
class DialogNovoFiado(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Registrar Fiado")
        self.setMinimumWidth(380); self.setModal(True)
        layout = QFormLayout(self); layout.setContentsMargins(20, 20, 20, 20)
        self.txt_cliente = QLineEdit(); self.txt_cliente.setPlaceholderText("Nome do cliente")
        self.txt_telefone = QLineEdit(); self.txt_telefone.setPlaceholderText("(opcional)")
        self.txt_produto = QLineEdit(); self.txt_produto.setPlaceholderText("Ex: 2 coxinhas + 1 guarana")
        self.sp_qtd = QSpinBox(); self.sp_qtd.setMinimum(1); self.sp_qtd.setMaximum(999)
        self.sp_valor = QDoubleSpinBox(); self.sp_valor.setMaximum(1_000_000)
        self.sp_valor.setDecimals(2); self.sp_valor.setPrefix("R$ ")
        self.txt_obs = QTextEdit(); self.txt_obs.setMaximumHeight(60)
        layout.addRow("Cliente:", self.txt_cliente); layout.addRow("Telefone:", self.txt_telefone)
        layout.addRow("Produto:", self.txt_produto); layout.addRow("Quantidade:", self.sp_qtd)
        layout.addRow("Valor total:", self.sp_valor); layout.addRow("Observacao:", self.txt_obs)
        b = QHBoxLayout()
        ok = QPushButton("Salvar"); ok.setObjectName("primary"); ok.clicked.connect(self._salvar)
        c = QPushButton("Cancelar"); c.clicked.connect(self.reject)
        b.addWidget(ok); b.addWidget(c); layout.addRow(b)

    def _salvar(self):
        if not self.txt_cliente.text().strip():
            QMessageBox.warning(self, "Erro", "Informe o cliente."); return
        if not self.txt_produto.text().strip():
            QMessageBox.warning(self, "Erro", "Informe o produto."); return
        if self.sp_valor.value() <= 0:
            QMessageBox.warning(self, "Erro", "Informe o valor."); return
        self.accept()

    def dados(self):
        return {"cliente": self.txt_cliente.text().strip(), "telefone": self.txt_telefone.text().strip(),
                "produto": self.txt_produto.text().strip(), "quantidade": self.sp_qtd.value(),
                "valor": self.sp_valor.value(), "observacao": self.txt_obs.toPlainText().strip()}

# =========================================================
# DIALOGO EDITAR PRODUTO
# =========================================================
class DialogEditarProduto(QDialog):
    def __init__(self, db: Database, produto: dict, parent=None):
        super().__init__(parent)
        self.db = db
        self.produto = produto
        self.setWindowTitle("Editar produto")
        self.setMinimumWidth(420)
        self.setModal(True)
        self._build()

    def _build(self):
        self.setStyleSheet("""
            QDialog { background: #f8fafc; }
            QLabel { background: transparent; color: #1e293b; }
            QLineEdit, QComboBox, QDoubleSpinBox, QSpinBox {
                background: white; border: 2px solid #e2e8f0;
                border-radius: 10px; padding: 9px 12px; color: #1e293b;
            }
            QLineEdit:focus, QComboBox:focus,
            QDoubleSpinBox:focus, QSpinBox:focus { border: 2px solid #4f46e5; }
            QPushButton#ok {
                background-color: #4f46e5; color: white; border: none;
                border-radius: 10px; padding: 12px; font-weight: 700;
            }
            QPushButton#ok:hover { background-color: #4338ca; }
            QPushButton#cancel {
                background-color: white; color: #64748b;
                border: 1px solid #cbd5e1; border-radius: 10px; padding: 12px;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        t = QLabel("✏️  Editar produto")
        t.setStyleSheet("font-size: 16pt; font-weight: 900; color: #4f46e5;")
        layout.addWidget(t)

        form = QFormLayout(); form.setSpacing(10)

        self.txt_nome = QLineEdit(self.produto["nome"])
        self.sp_preco = QDoubleSpinBox()
        self.sp_preco.setMaximum(1_000_000); self.sp_preco.setDecimals(2)
        self.sp_preco.setPrefix("R$ "); self.sp_preco.setValue(self.produto["preco"])

        self.sp_estoque = QSpinBox()
        self.sp_estoque.setMaximum(1_000_000)
        self.sp_estoque.setValue(self.produto["estoque"])

        self.sp_minimo = QSpinBox()
        self.sp_minimo.setMaximum(1_000_000)
        self.sp_minimo.setValue(self.produto.get("estoque_minimo", 5))

        self.cmb_categoria = QComboBox(); self.cmb_categoria.setEditable(True)
        self.cmb_categoria.addItems(["Bebidas", "Salgados", "Pratos",
                                      "Gelados", "Doces", "Geral"])
        self.cmb_categoria.setCurrentText(self.produto.get("categoria", "Geral"))

        form.addRow("Nome:", self.txt_nome)
        form.addRow("Preco:", self.sp_preco)
        form.addRow("Estoque:", self.sp_estoque)
        form.addRow("Estoque minimo:", self.sp_minimo)
        form.addRow("Categoria:", self.cmb_categoria)
        layout.addLayout(form)

        b = QHBoxLayout()
        ok = QPushButton("Salvar"); ok.setObjectName("ok"); ok.setMinimumHeight(44)
        ok.clicked.connect(self._salvar)
        c = QPushButton("Cancelar"); c.setObjectName("cancel"); c.setMinimumHeight(44)
        c.clicked.connect(self.reject)
        b.addWidget(ok, 2); b.addWidget(c, 1)
        layout.addLayout(b)

    def _salvar(self):
        nome = self.txt_nome.text().strip()
        if not nome:
            QMessageBox.warning(self, "Erro", "Informe o nome do produto.")
            return
        categoria = self.cmb_categoria.currentText().strip() or "Geral"
        self.db.atualizar_produto(
            self.produto["id"], nome, self.sp_preco.value(),
            self.sp_estoque.value(), categoria
        )
        # atualizar estoque_minimo (campo nao coberto por atualizar_produto)
        with self.db._conectar() as conn:
            conn.execute("UPDATE produtos SET estoque_minimo=? WHERE id=?",
                         (self.sp_minimo.value(), self.produto["id"]))
        QMessageBox.information(self, "OK", "Produto atualizado!")
        self.accept()

# =========================================================
# TELA DE LOGIN
# =========================================================
class TelaLogin(QDialog):
    def __init__(self, db: Database, parent=None):
        super().__init__(parent)
        self.db = db
        self.usuario_logado = None
        self.setWindowTitle("Bem-vindo - Loja Pablo")
        self.setFixedSize(440, 560); self.setModal(True)
        self._build()

    def _build(self):
        self.setStyleSheet("""
            QDialog { background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                stop:0 #eef2ff, stop:1 #f8fafc); }
            QLabel { background: transparent; color: #1e293b; }
            QLineEdit { background: white; border: 2px solid #e2e8f0;
                border-radius: 10px; padding: 14px 16px; font-size: 12pt; color: #1e293b; }
            QLineEdit:focus { border: 2px solid #4f46e5; }
            QPushButton#entrar { background-color: #4f46e5; color: white;
                border: none; border-radius: 10px; padding: 16px;
                font-size: 14pt; font-weight: 800; letter-spacing: 1px; }
            QPushButton#entrar:hover { background-color: #4338ca; }
            QPushButton#fiado { background-color: transparent; color: #f59e0b;
                border: 2px solid #f59e0b; border-radius: 10px; padding: 14px;
                font-size: 12pt; font-weight: 700; }
            QPushButton#fiado:hover { background-color: #fffbeb; }
            QPushButton#admin { background-color: transparent; color: #64748b;
                border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px;
                font-size: 10pt; font-weight: 600; }
            QPushButton#admin:hover { background-color: #f1f5f9; color: #4f46e5; }
            QFrame#card { background: white; border: 1px solid #e2e8f0; border-radius: 16px; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30); layout.setSpacing(10)

        icone = QLabel("🛒"); icone.setAlignment(Qt.AlignCenter)
        icone.setStyleSheet("font-size: 48pt;"); layout.addWidget(icone)

        nome = QLabel("LOJA PABLO"); nome.setAlignment(Qt.AlignCenter)
        nome.setStyleSheet("font-size: 22pt; font-weight: 900; color: #4f46e5; letter-spacing: 2px;")
        layout.addWidget(nome)

        sub = QLabel("Como podemos te chamar?")
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("font-size: 12pt; color: #64748b; padding-bottom: 12px;")
        layout.addWidget(sub)

        card = QFrame(); card.setObjectName("card")
        cl = QVBoxLayout(card); cl.setContentsMargins(24, 24, 24, 24); cl.setSpacing(12)

        cl.addWidget(QLabel("<b style='color:#1e293b;'>Seu nome:</b>"))
        self.txt_usuario = QLineEdit()
        self.txt_usuario.setPlaceholderText("Ex: João")
        self.txt_usuario.returnPressed.connect(self._entrar)
        cl.addWidget(self.txt_usuario)
        cl.addSpacing(4)

        btn = QPushButton("ENTRAR")
        btn.setObjectName("entrar")
        btn.setCursor(Qt.PointingHandCursor); btn.setMinimumHeight(55)
        btn.clicked.connect(self._entrar)
        cl.addWidget(btn)

        layout.addWidget(card)
        layout.addSpacing(6)

        btn_fiado = QPushButton("💳  Quero usar fiado")
        btn_fiado.setObjectName("fiado"); btn_fiado.setCursor(Qt.PointingHandCursor)
        btn_fiado.setMinimumHeight(50); btn_fiado.clicked.connect(self._abrir_cadastro)
        layout.addWidget(btn_fiado)

        layout.addSpacing(8)
        btn_admin = QPushButton("🔒  Entrar como funcionário")
        btn_admin.setObjectName("admin"); btn_admin.setCursor(Qt.PointingHandCursor)
        btn_admin.setMinimumHeight(40); btn_admin.clicked.connect(self._login_funcionario)
        layout.addWidget(btn_admin)

        layout.addStretch()
        self.txt_usuario.setFocus()

    def _entrar(self):
        nome = self.txt_usuario.text().strip()
        if not nome:
            QMessageBox.warning(self, "Erro", "Digite seu nome."); return
        c = self.db.buscar_cliente(nome)
        if c:
            self.usuario_logado = {"usuario": nome, "tipo": "cliente",
                                    "cliente_nome": nome, "cadastrado": True}
        else:
            self.usuario_logado = {"usuario": nome, "tipo": "cliente",
                                    "cliente_nome": nome, "cadastrado": False}
        self.accept()

    def _abrir_cadastro(self):
        dlg = DialogCadastroCliente(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.usuario_logado = {
                "usuario": dlg.cliente_logado["usuario"],
                "tipo": "cliente",
                "cliente_nome": dlg.cliente_logado["cliente_nome"],
                "cadastrado": True,
            }
            self.accept()

    def _login_funcionario(self):
        dlg = DialogLoginFuncionario(self.db, self)
        if dlg.exec() == QDialog.Accepted:
            self.usuario_logado = dlg.usuario_logado
            self.accept()


# =========================================================
# CARD DE PRODUTO
# =========================================================
class CardProduto(QFrame):
    def __init__(self, produto, ao_clicar):
        super().__init__()
        self.produto = produto; self.ao_clicar = ao_clicar
        self.setObjectName("cardProduto")
        self.setFixedSize(180, 240); self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("""
            QFrame#cardProduto { background: white; border: 1px solid #e2e8f0; border-radius: 14px; }
            QFrame#cardProduto:hover { border: 2px solid #4f46e5; background: #fafbff; }
            QFrame#cardProduto QLabel { background: transparent; }
        """)
        lay = QVBoxLayout(self); lay.setContentsMargins(10, 10, 10, 10); lay.setSpacing(4)

        li = QLabel(); li.setFixedHeight(110); li.setAlignment(Qt.AlignCenter)
        tipo = produto.get("imagem", "geral") or "geral"
        px = QPixmap(caminho_imagem(tipo))
        if not px.isNull():
            px = px.scaled(110, 110, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            li.setPixmap(px)

        ln = QLabel(produto["nome"]); ln.setWordWrap(True); ln.setAlignment(Qt.AlignCenter)
        ln.setStyleSheet("font-size: 9pt; font-weight: 600; color: #1e293b;"); ln.setFixedHeight(38)

        le = QLabel(f"Estoque: {produto['estoque']}"); le.setAlignment(Qt.AlignCenter)
        le.setStyleSheet("font-size: 8pt; color: #94a3b8;")

        lp = QLabel(f"R$ {produto['preco']:.2f}".replace(".", ",")); lp.setAlignment(Qt.AlignCenter)
        lp.setStyleSheet("font-size: 13pt; font-weight: 800; color: #10b981;")

        lay.addWidget(li); lay.addWidget(ln); lay.addWidget(le); lay.addStretch(); lay.addWidget(lp)

    def mousePressEvent(self, event):
        self.ao_clicar(self.produto)


# =========================================================
# DIALOGO DE PAGAMENTO
# =========================================================
class DialogPagamento(QDialog):
    def __init__(self, db: Database, cliente, carrinho, parent=None):
        super().__init__(parent)
        self.db = db; self.cliente = cliente; self.carrinho = list(carrinho)
        self.forma_selecionada = "Dinheiro"
        self.setWindowTitle("Pagamento")
        self.setMinimumSize(620, 700); self.setModal(True)
        self._build()

    def _build(self):
        self.setStyleSheet("""
            QDialog { background: #f8fafc; }
            QLabel { background: transparent; color: #1e293b; }
            QFrame#card { background: white; border: 1px solid #e2e8f0; border-radius: 14px; }
            QPushButton#pag { background: #10b981; color: white; border: none;
                border-radius: 12px; padding: 16px; font-size: 14pt; font-weight: 800; }
            QPushButton#pag:hover { background: #059669; }
            QPushButton#cancel { background: white; color: #64748b;
                border: 1px solid #cbd5e1; border-radius: 12px; padding: 16px; font-weight: 700; }
        """)
        layout = QVBoxLayout(self); layout.setContentsMargins(28, 28, 28, 28); layout.setSpacing(14)

        t = QLabel("💳  Finalizar pagamento")
        t.setStyleSheet("font-size: 20pt; font-weight: 900; color: #4f46e5;")
        layout.addWidget(t)

        sub = QLabel(f"Cliente: <b>{self.cliente}</b>")
        sub.setStyleSheet("font-size: 11pt; color: #64748b;")
        layout.addWidget(sub)

        card = QFrame(); card.setObjectName("card")
        cl = QVBoxLayout(card); cl.setContentsMargins(20, 20, 20, 20); cl.setSpacing(12)

        titulo_itens = QLabel("Itens do pedido")
        titulo_itens.setStyleSheet("font-size: 13pt; font-weight: 700; color: #1e293b;")
        cl.addWidget(titulo_itens)

        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(["Produto", "Qtd", "Unit.", "Subtotal"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.verticalHeader().setVisible(False)
        self.tabela.setMinimumHeight(200)
        self.tabela.setStyleSheet("""
            QTableWidget { background: white; color: #1e293b;
                border: 1px solid #e2e8f0; border-radius: 10px; }
            QTableWidget::item { padding: 8px; color: #1e293b; }
            QHeaderView::section { background: #f8fafc; color: #64748b; border: none;
                border-bottom: 2px solid #e2e8f0; padding: 10px; font-weight: 700; }
        """)
        cl.addWidget(self.tabela)

        self.lbl_total = QLabel(); self.lbl_total.setAlignment(Qt.AlignRight)
        self.lbl_total.setStyleSheet("font-size: 22pt; font-weight: 900; color: #10b981;")
        cl.addWidget(self.lbl_total)

        lbl_forma = QLabel("Forma de pagamento")
        lbl_forma.setStyleSheet("font-size: 13pt; font-weight: 700; color: #1e293b; padding-top: 6px;")
        cl.addWidget(lbl_forma)

        grid_formas = QGridLayout(); grid_formas.setSpacing(12)
        self.botoes_forma = {}
        formas = [
            ("Dinheiro",       "💵", "#10b981"),
            ("Cartão Débito",  "💳", "#3b82f6"),
            ("Cartão Crédito", "💳", "#8b5cf6"),
            ("PIX",            "⚡", "#f59e0b"),
        ]
        for i, (nome, emoji, cor) in enumerate(formas):
            b = QPushButton(f"{emoji}\n{nome}")
            b.setCheckable(True); b.setCursor(Qt.PointingHandCursor); b.setMinimumHeight(85)
            b.setStyleSheet(f"""
                QPushButton {{ background: white; border: 2px solid #e2e8f0;
                    border-radius: 12px; padding: 10px; font-size: 11pt;
                    font-weight: 700; color: #1e293b; text-align: center; }}
                QPushButton:hover {{ border-color: {cor}; background: #f8fafc; }}
                QPushButton:checked {{ background: {cor}; color: white; border: 3px solid {cor}; }}
            """)
            b.clicked.connect(lambda _, n=nome: self._selecionar_forma(n))
            self.botoes_forma[nome] = b
            r, c = divmod(i, 2); grid_formas.addWidget(b, r, c)
        cl.addLayout(grid_formas)
        self.botoes_forma["Dinheiro"].setChecked(True)

        layout.addWidget(card)

        b = QHBoxLayout()
        btn_pag = QPushButton("CONFIRMAR PAGAMENTO"); btn_pag.setObjectName("pag")
        btn_pag.setMinimumHeight(60); btn_pag.clicked.connect(self._pagar)
        btn_cancel = QPushButton("Cancelar"); btn_cancel.setObjectName("cancel")
        btn_cancel.setMinimumHeight(60); btn_cancel.clicked.connect(self.reject)
        b.addWidget(btn_pag, 3); b.addWidget(btn_cancel, 1)
        layout.addLayout(b)

        self._preencher()

    def _selecionar_forma(self, nome):
        self.forma_selecionada = nome
        for n, b in self.botoes_forma.items():
            b.setChecked(n == nome)

    def _preencher(self):
        self.tabela.setRowCount(0); total = 0.0
        for it in self.carrinho:
            sub = it["quantidade"] * it["preco_unitario"]; total += sub
            r = self.tabela.rowCount(); self.tabela.insertRow(r)
            self.tabela.setItem(r, 0, QTableWidgetItem(it["nome"]))
            self.tabela.setItem(r, 1, QTableWidgetItem(f"{it['quantidade']}x"))
            self.tabela.setItem(r, 2, QTableWidgetItem(f"R$ {it['preco_unitario']:.2f}"))
            self.tabela.setItem(r, 3, QTableWidgetItem(f"R$ {sub:.2f}"))
        self.lbl_total.setText(f"TOTAL:  R$ {total:.2f}".replace(".", ","))

    def _pagar(self):
        total = sum(i["quantidade"] * i["preco_unitario"] for i in self.carrinho)
        forma = self.forma_selecionada

        if forma == "PIX":
            caminho_qr, payload = self._gerar_pix(total)
            if not caminho_qr: return
            dlg = DialogPix(caminho_qr, payload, total, self)
            if dlg.exec() != QDialog.Accepted: return

        try:
            venda_id, total = self.db.registrar_venda(self.carrinho, forma, self.cliente)
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha ao registrar venda:\n{e}"); return

        itens_texto = " | ".join(f"{i['quantidade']}x {i['nome']}" for i in self.carrinho)
        try:
            pedidos.criar_pedido(itens_texto, total, forma, self.cliente)
        except Exception as e:
            print(f"[Totem] Erro cozinha: {e}")

        try:
            self.db.criar_pedido_cliente(self.cliente, itens_texto, total)
        except Exception:
            pass

        QMessageBox.information(self, "Pagamento confirmado!",
            f"Obrigado, {self.cliente}!\n\nTotal: R$ {total:.2f}\nForma: {forma}\n\n"
            "Seu pedido foi enviado para a cozinha.")
        self.accept()

    def _gerar_pix(self, valor):
        if not PIX_DISPONIVEL:
            QMessageBox.critical(self, "Pix indisponível", "Instale: pip install pixcore"); return None, None
        cfg = carregar_config()
        if not cfg.get("pix_chave", "").strip():
            QMessageBox.warning(self, "Pix não configurado", "Peça ao administrador."); return None, None
        try:
            dados = PixData(recebedor_nome=cfg["pix_nome"].upper(),
                            recebedor_cidade=cfg["pix_cidade"].upper(),
                            pix_key=cfg["pix_chave"].strip(), valor=valor,
                            transacao_id=f"VENDA{datetime.now().strftime('%Y%m%d%H%M%S')}")
            gerador = Pix(dados)
            caminho = os.path.join(os.path.dirname(__file__), "pix_temp.png")
            gerador.save_qrcode(caminho)
            return caminho, gerador.payload()
        except Exception as e:
            QMessageBox.critical(self, "Erro no Pix", f"Falha:\n{e}"); return None, None


# =========================================================
# TOTEM DO CLIENTE
# =========================================================
class TotemCliente(QWidget):
    def __init__(self, db: Database, cliente_nome, ao_sair, ao_atualizar_saldo, cadastrado=True):
        super().__init__()
        self.db = db; self.cliente = cliente_nome
        self.ao_sair = ao_sair; self.ao_atualizar_saldo = ao_atualizar_saldo
        self.cadastrado = cadastrado
        self.carrinho = []; self.categoria_atual = "Todas"
        self._build()
        self._atualizar_saldo_topo()
        self.atualizar_disponiveis()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20); layout.setSpacing(14)

        topo = QFrame(); topo.setObjectName("card")
        topo_lay = QHBoxLayout(topo); topo_lay.setContentsMargins(20, 14, 20, 14)
        ola = QLabel(f"Olá, <b>{self.cliente}</b>! O que vai querer hoje?")
        ola.setStyleSheet("font-size: 15pt; color: #1e293b;")
        topo_lay.addWidget(ola); topo_lay.addStretch()

        self.lbl_saldo = QLabel("")
        self.lbl_saldo.setTextFormat(Qt.RichText)
        self.lbl_saldo.setStyleSheet("""
            background: #eef2ff; color: #4f46e5; font-weight: 700;
            padding: 8px 14px; border-radius: 10px;
        """)
        topo_lay.addWidget(self.lbl_saldo)
        layout.addWidget(topo)

        chips = QHBoxLayout(); chips.setSpacing(8)
        self.btn_chips = {}
        for cat in ["Todas", "Bebidas", "Salgados", "Pratos", "Gelados"]:
            b = QPushButton(cat); b.setCheckable(True); b.setObjectName("navBtn")
            b.setCursor(Qt.PointingHandCursor); b.setMinimumHeight(40)
            b.clicked.connect(lambda _, c=cat: self._selecionar_categoria(c))
            chips.addWidget(b); self.btn_chips[cat] = b
        chips.addStretch()
        self.btn_chips["Todas"].setChecked(True)
        layout.addLayout(chips)

        corpo = QHBoxLayout(); corpo.setSpacing(16)

        esq = QFrame(); esq.setObjectName("card")
        lay_e = QVBoxLayout(esq); lay_e.setContentsMargins(16, 16, 16, 16); lay_e.setSpacing(10)

        self.txt_busca = QLineEdit(); self.txt_busca.setPlaceholderText("Buscar produto...")
        self.txt_busca.textChanged.connect(self.atualizar_disponiveis)
        lay_e.addWidget(self.txt_busca)

        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.grid_w = QWidget()
        self.grid = QGridLayout(self.grid_w); self.grid.setSpacing(12)
        self.grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.grid_w)
        lay_e.addWidget(self.scroll, 1)

        dir_ = QFrame(); dir_.setObjectName("card"); dir_.setFixedWidth(400)
        lay_d = QVBoxLayout(dir_); lay_d.setContentsMargins(16, 16, 16, 16); lay_d.setSpacing(10)

        t = QLabel("🛒  Meu pedido"); t.setStyleSheet("font-size: 13pt; font-weight: 800; color: #4f46e5;")
        lay_d.addWidget(t)

        self.tabela = QTableWidget(0, 3)
        self.tabela.setHorizontalHeaderLabels(["Produto", "Qtd", "Subtotal"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.verticalHeader().setVisible(False)
        lay_d.addWidget(self.tabela, 1)

        linha = QHBoxLayout()
        m = QPushButton("+"); mn = QPushButton("-"); rm = QPushButton("Remover")
        m.clicked.connect(lambda: self._alterar_qtd(1))
        mn.clicked.connect(lambda: self._alterar_qtd(-1))
        rm.clicked.connect(self._remover)
        linha.addWidget(m); linha.addWidget(mn); linha.addWidget(rm); linha.addStretch()
        lay_d.addLayout(linha)

        self.lbl_total = QLabel("R$ 0,00")
        self.lbl_total.setAlignment(Qt.AlignRight)
        self.lbl_total.setStyleSheet("font-size: 22pt; font-weight: 800; color: #10b981;")
        lay_d.addWidget(self.lbl_total)

        btn_pagar = QPushButton("💳  PAGAR AGORA")
        btn_pagar.setStyleSheet("""
            background: #10b981; color: white; border: none;
            border-radius: 12px; padding: 16px; font-size: 13pt; font-weight: 800;
        """)
        btn_pagar.setMinimumHeight(55); btn_pagar.clicked.connect(self._pagar_agora)
        lay_d.addWidget(btn_pagar)

        btn_fiado = QPushButton("📝  Adicionar ao meu fiado")
        btn_fiado.setStyleSheet("""
            background: #f59e0b; color: white; border: none;
            border-radius: 12px; padding: 14px; font-size: 12pt; font-weight: 800;
        """)
        btn_fiado.setMinimumHeight(50); btn_fiado.clicked.connect(self._adicionar_fiado)
        lay_d.addWidget(btn_fiado)

        corpo.addWidget(esq, 1); corpo.addWidget(dir_)
        layout.addLayout(corpo)

    def _atualizar_saldo_topo(self):
        if not self.cadastrado:
            self.lbl_saldo.setText(
                "<span style='color:#f59e0b;'>⚠️ Sem cadastro — só pagamento à vista</span>"
            )
            return
        limite, devedor, disp = self.db.limite_disponivel_cliente(self.cliente)
        cor = "#10b981" if disp > 0 else "#ef4444"
        self.lbl_saldo.setText(
            f"Deve <b>R$ {devedor:.2f}</b>  •  Limite R$ {limite:.2f}  •  Disponível "
            f"<span style='color:{cor}'><b>R$ {disp:.2f}</b></span>"
        )

    def _selecionar_categoria(self, cat):
        self.categoria_atual = cat
        for c, b in self.btn_chips.items():
            b.setChecked(c == cat)
        self.atualizar_disponiveis()

    def atualizar_disponiveis(self):
        while self.grid.count():
            it = self.grid.takeAt(0); w = it.widget()
            if w: w.deleteLater()
        filtro = self.txt_busca.text().strip()
        produtos = self.db.listar_produtos(filtro, self.categoria_atual)
        colunas = 4; pos = 0
        for p in produtos:
            if p["estoque"] <= 0: continue
            card = CardProduto(p, self._adicionar_produto)
            r, c = divmod(pos, colunas); self.grid.addWidget(card, r, c); pos += 1

    def _adicionar_produto(self, produto):
        item = next((i for i in self.carrinho if i["produto_id"] == produto["id"]), None)
        qa = item["quantidade"] if item else 0
        if qa + 1 > produto["estoque"]:
            QMessageBox.warning(self, "Estoque", f"Estoque disponível: {produto['estoque']}"); return
        if item: item["quantidade"] += 1
        else:
            self.carrinho.append({"produto_id": produto["id"], "nome": produto["nome"],
                                  "quantidade": 1, "preco_unitario": produto["preco"]})
        self._atualizar()

    def _alterar_qtd(self, d):
        row = self.tabela.currentRow()
        if row < 0: return
        item = self.carrinho[row]
        prod = self.db.buscar_produto(item["produto_id"])
        nova = item["quantidade"] + d
        if nova <= 0: self.carrinho.pop(row)
        elif nova > prod["estoque"]:
            QMessageBox.warning(self, "Estoque", f"Máximo: {prod['estoque']}"); return
        else: item["quantidade"] = nova
        self._atualizar()

    def _remover(self):
        row = self.tabela.currentRow()
        if row < 0: return
        self.carrinho.pop(row); self._atualizar()

    def _atualizar(self):
        self.tabela.setRowCount(0); total = 0.0
        for it in self.carrinho:
            sub = it["quantidade"] * it["preco_unitario"]; total += sub
            r = self.tabela.rowCount(); self.tabela.insertRow(r)
            self.tabela.setItem(r, 0, QTableWidgetItem(it["nome"]))
            self.tabela.setItem(r, 1, QTableWidgetItem(f"{it['quantidade']}x"))
            self.tabela.setItem(r, 2, QTableWidgetItem(f"R$ {sub:.2f}"))
        self.lbl_total.setText(f"R$ {total:.2f}".replace(".", ","))

    def _total_carrinho(self):
        return sum(i["quantidade"] * i["preco_unitario"] for i in self.carrinho)

    def _pagar_agora(self):
        if not self.carrinho:
            QMessageBox.warning(self, "Aviso", "Adicione algum produto primeiro."); return
        dlg = DialogPagamento(self.db, self.cliente, self.carrinho, self)
        if dlg.exec() == QDialog.Accepted:
            self.carrinho.clear(); self._atualizar(); self.atualizar_disponiveis()
            self._atualizar_saldo_topo()

    def _adicionar_fiado(self):
        if not self.carrinho:
            QMessageBox.warning(self, "Aviso", "Adicione algum produto primeiro."); return
        if not self.cadastrado:
            QMessageBox.warning(self, "Sem cadastro",
                "Você ainda não tem cadastro fiado.\n\n"
                "Clique em 'Registrar fiado' no topo da tela para se cadastrar.")
            return

        total = self._total_carrinho()
        limite, devedor, disp = self.db.limite_disponivel_cliente(self.cliente)
        if total > disp:
            QMessageBox.critical(self, "Limite excedido",
                f"Você não pode adicionar esse pedido ao fiado.\n\n"
                f"Total: R$ {total:.2f}\nLimite disponível: R$ {disp:.2f}")
            return

        if not msg_confirmar(self, "Confirmar fiado",
            f"Adicionar R$ {total:.2f} ao seu fiado?".replace(".", ","),
            f"Saldo após: R$ {devedor + total:.2f} de R$ {limite:.2f}".replace(".", ","),
            sim="Sim, adicionar", nao="Não, cancelar"):
            return

        desc = ", ".join(f"{i['quantidade']}x {i['nome']}" for i in self.carrinho)
        qtd = sum(i["quantidade"] for i in self.carrinho)
        self.db.adicionar_fiado(self.cliente, "", desc, qtd, total, "Pedido pelo totem")

        itens_texto = " | ".join(f"{i['quantidade']}x {i['nome']}" for i in self.carrinho)
        try:
            pedidos.criar_pedido(itens_texto, total, "Fiado", self.cliente)
        except Exception as e:
            print(f"[Totem] Erro cozinha: {e}")

        for it in self.carrinho:
            self.db.adicionar_estoque(it["produto_id"], -it["quantidade"])

        QMessageBox.information(self, "Adicionado!",
            f"Pedido adicionado ao seu fiado!\n\nSaldo devedor: R$ {devedor + total:.2f}")
        self.carrinho.clear(); self._atualizar(); self.atualizar_disponiveis()
        self._atualizar_saldo_topo()
        self.ao_atualizar_saldo()


# =========================================================
# PAGINA INICIAL (admin/vendedor)
# =========================================================
class PaginaInicial(QWidget):
    def __init__(self, ir_para, tipo_usuario):
        super().__init__()
        self.ir_para = ir_para; self.tipo_usuario = tipo_usuario
        self._kpi_widgets = []; self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24); layout.setSpacing(18)
        layout.addWidget(titulo_pagina("Bem-vindo", "Escolha uma opcao abaixo para comecar."))

        kpis = QHBoxLayout(); kpis.setSpacing(14)
        self.kpi_produtos = self._criar_kpi("Produtos", "0", "#4f46e5", "#6366f1", icone_produtos())
        self.kpi_vendas = self._criar_kpi("Vendas hoje", "0", "#059669", "#10b981", icone_vendas())
        self.kpi_total = self._criar_kpi("Faturamento hoje", "R$ 0,00", "#d97706", "#f59e0b", icone_dinheiro())
        self.kpi_fiados = self._criar_kpi("Fiados pendentes", "R$ 0,00", "#dc2626", "#ef4444", icone_dinheiro())
        for w in self._kpi_widgets: kpis.addWidget(w)
        layout.addLayout(kpis)

        grid = QGridLayout(); grid.setSpacing(16)
        grid.addWidget(self._card_atalho(icone_vendas(), "Vendas (PDV)",
            "Abra o caixa e registre novas vendas.", lambda: self.ir_para("vendas")), 0, 0)
        grid.addWidget(self._card_atalho(icone_dinheiro(), "Fiados",
            "Registre quem esta devendo.", lambda: self.ir_para("fiados")), 0, 1)
        grid.addWidget(self._card_atalho(icone_produtos(), "Estoque",
            "Consulte a quantidade disponivel.", lambda: self.ir_para("estoque")), 0, 2)

        if self.tipo_usuario == "admin":
            grid.addWidget(self._card_atalho(icone_produtos(), "Produtos",
                "Cadastre e gerencie os produtos.", lambda: self.ir_para("produtos")), 1, 0)
            grid.addWidget(self._card_atalho(icone_historico(), "Historico",
                "Veja o historico completo.", lambda: self.ir_para("historico")), 1, 1)
            grid.addWidget(self._card_atalho(icone_home(), "Configuracoes",
                "Pix, nome da loja e limites.", lambda: self.ir_para("config")), 1, 2)

        layout.addLayout(grid); layout.addStretch()

    def _criar_kpi(self, titulo, valor, cor1, cor2, icone_svg):
        f = QFrame(); f.setObjectName("card"); f.setMinimumHeight(110)
        f.setStyleSheet(f"""
            QFrame#card {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 {cor1}, stop:1 {cor2});
                border: none; border-radius: 14px;
            }}
            QLabel {{ color: white; background: transparent; }}
        """)
        lay = QVBoxLayout(f); lay.setContentsMargins(18, 14, 18, 14); lay.setSpacing(4)
        topo = QHBoxLayout()
        lbl_t = QLabel(titulo.upper()); lbl_t.setStyleSheet("font-size: 9pt; font-weight: 700; letter-spacing: 0.5px;")
        lbl_ic = QLabel()
        lbl_ic.setPixmap(svg_icon(icone_svg.replace("#2d3436", "#ffffff"), 22).pixmap(22, 22))
        topo.addWidget(lbl_t); topo.addStretch(); topo.addWidget(lbl_ic)
        lbl_v = QLabel(valor); lbl_v.setStyleSheet("font-size: 20pt; font-weight: 800; color: white;")
        lay.addLayout(topo); lay.addWidget(lbl_v)
        self._kpi_widgets.append(f)
        return lbl_v

    def _card_atalho(self, icone_svg, titulo, descricao, callback):
        f = QFrame(); f.setObjectName("cardAtalho"); f.setMinimumHeight(180)
        f.setCursor(Qt.PointingHandCursor)
        lay = QVBoxLayout(f); lay.setContentsMargins(22, 22, 22, 22); lay.setSpacing(10)
        chip = QFrame(); chip.setFixedSize(52, 52)
        chip.setStyleSheet("background: #eef2ff; border-radius: 14px;")
        chip_lay = QVBoxLayout(chip); chip_lay.setContentsMargins(0, 0, 0, 0)
        lbl_ic = QLabel()
        lbl_ic.setPixmap(svg_icon(icone_svg.replace("#2d3436", "#4f46e5"), 26).pixmap(26, 26))
        lbl_ic.setAlignment(Qt.AlignCenter); chip_lay.addWidget(lbl_ic)
        lbl_t = QLabel(titulo); lbl_t.setObjectName("tituloCard")
        lbl_d = QLabel(descricao); lbl_d.setObjectName("subtituloCard"); lbl_d.setWordWrap(True)
        btn = QPushButton("Abrir  ->"); btn.setObjectName("primary"); btn.clicked.connect(callback)
        lay.addWidget(chip, alignment=Qt.AlignLeft)
        lay.addWidget(lbl_t); lay.addWidget(lbl_d); lay.addStretch(); lay.addWidget(btn)
        f.mousePressEvent = lambda e: callback()
        return f

    def atualizar_kpis(self, db: Database):
        produtos = db.listar_produtos()
        self.kpi_produtos.setText(str(len(produtos)))
        hoje = date.today().strftime("%Y-%m-%d")
        vendas = db.listar_vendas()
        vendas_hoje = [v for v in vendas if v["data"].startswith(hoje)]
        total_hoje = sum(v["total"] for v in vendas_hoje)
        self.kpi_vendas.setText(str(len(vendas_hoje)))
        self.kpi_total.setText(f"R$ {total_hoje:.2f}".replace(".", ","))
        self.kpi_fiados.setText(f"R$ {db.total_fiados_pendentes():.2f}".replace(".", ","))

# =========================================================
# PAGINA PRODUTOS + ESTOQUE (unificada)
# =========================================================
class PaginaProdutosEstoque(QWidget):
    def __init__(self, db: Database, ao_mudar_produtos, tipo_usuario):
        super().__init__()
        self.db = db
        self.ao_mudar_produtos = ao_mudar_produtos
        self.tipo_usuario = tipo_usuario
        self._build()
        self.carregar()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        subt = ("Cadastre, edite produtos e gerencie o estoque."
                if self.tipo_usuario == "admin"
                else "Consulte a quantidade disponivel.")
        layout.addWidget(titulo_pagina("Produtos & Estoque", subt))

        # ---------- Formulario de cadastro (somente admin) ----------
        if self.tipo_usuario == "admin":
            form_card = QFrame(); form_card.setObjectName("card")
            form = QHBoxLayout(form_card)
            form.setContentsMargins(16, 16, 16, 16); form.setSpacing(12)

            self.txt_nome = QLineEdit()
            self.txt_nome.setPlaceholderText("Nome do produto")
            self.txt_nome.setMinimumWidth(200)

            self.sp_preco = QDoubleSpinBox()
            self.sp_preco.setMaximum(1_000_000); self.sp_preco.setDecimals(2)
            self.sp_preco.setPrefix("R$ "); self.sp_preco.setMinimumWidth(110)

            self.sp_estoque = QSpinBox()
            self.sp_estoque.setMaximum(1_000_000); self.sp_estoque.setMinimumWidth(90)

            self.sp_minimo = QSpinBox()
            self.sp_minimo.setMaximum(1_000_000); self.sp_minimo.setMinimumWidth(90)
            self.sp_minimo.setValue(5)

            self.cmb_categoria = QComboBox(); self.cmb_categoria.setEditable(True)
            self.cmb_categoria.addItems(["Bebidas", "Salgados", "Pratos",
                                          "Gelados", "Doces", "Geral"])
            self.cmb_categoria.setMinimumWidth(130)

            btn_salvar = QPushButton("Cadastrar")
            btn_salvar.setObjectName("primary")
            btn_salvar.clicked.connect(self.cadastrar)

            form.addWidget(QLabel("Nome:"));      form.addWidget(self.txt_nome, 2)
            form.addWidget(QLabel("Preco:"));     form.addWidget(self.sp_preco, 1)
            form.addWidget(QLabel("Estoque:"));   form.addWidget(self.sp_estoque, 1)
            form.addWidget(QLabel("Min.:"));      form.addWidget(self.sp_minimo, 1)
            form.addWidget(QLabel("Categoria:")); form.addWidget(self.cmb_categoria, 1)
            form.addWidget(btn_salvar)
            layout.addWidget(form_card)

        # ---------- Barra de acoes / filtros ----------
        acoes = QHBoxLayout()

        self.txt_busca = QLineEdit()
        self.txt_busca.setPlaceholderText("Buscar produto...")
        self.txt_busca.textChanged.connect(self.carregar)
        acoes.addWidget(self.txt_busca, 2)

        self.cmb_filtro = QComboBox()
        self.cmb_filtro.addItems(["Todos", "Somente estoque baixo"])
        self.cmb_filtro.currentTextChanged.connect(self.carregar)
        acoes.addWidget(self.cmb_filtro, 1)

        if self.tipo_usuario == "admin":
            btn_add = QPushButton("+ Estoque"); btn_add.setObjectName("primary")
            btn_add.clicked.connect(lambda: self.ajustar(1))
            acoes.addWidget(btn_add)

            btn_rem = QPushButton("- Estoque")
            btn_rem.clicked.connect(lambda: self.ajustar(-1))
            acoes.addWidget(btn_rem)

            btn_definir = QPushButton("Definir exato"); btn_definir.setObjectName("ghost")
            btn_definir.clicked.connect(self.definir_valor)
            acoes.addWidget(btn_definir)

            btn_editar = QPushButton("Editar produto"); btn_editar.setObjectName("ghost")
            btn_editar.clicked.connect(self.editar)
            acoes.addWidget(btn_editar)

            btn_excluir = QPushButton("Excluir"); btn_excluir.setObjectName("danger")
            btn_excluir.clicked.connect(self.excluir)
            acoes.addWidget(btn_excluir)

        layout.addLayout(acoes)

        # ---------- Tabela ----------
        self.tabela = QTableWidget(0, 7)
        self.tabela.setHorizontalHeaderLabels(
            ["ID", "Produto", "Categoria", "Preco (R$)", "Estoque", "Minimo", "Status"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.verticalHeader().setVisible(False)
        layout.addWidget(self.tabela)

    def carregar(self):
        filtro = self.txt_busca.text().strip()
        produtos = self.db.listar_produtos(filtro)
        somente_baixo = self.cmb_filtro.currentText() == "Somente estoque baixo"

        self.tabela.setRowCount(0)
        for p in produtos:
            minimo = p.get("estoque_minimo", 5)
            baixo = p["estoque"] <= minimo
            if somente_baixo and not baixo:
                continue

            r = self.tabela.rowCount(); self.tabela.insertRow(r)
            self.tabela.setItem(r, 0, QTableWidgetItem(str(p["id"])))
            self.tabela.setItem(r, 1, QTableWidgetItem(p["nome"]))
            self.tabela.setItem(r, 2, QTableWidgetItem(p.get("categoria", "Geral")))
            self.tabela.setItem(r, 3, QTableWidgetItem(f"{p['preco']:.2f}"))
            self.tabela.setItem(r, 4, QTableWidgetItem(str(p["estoque"])))
            self.tabela.setItem(r, 5, QTableWidgetItem(str(minimo)))

            item = QTableWidgetItem("BAIXO" if baixo else "OK")
            item.setForeground(Qt.red if baixo else Qt.darkGreen)
            self.tabela.setItem(r, 6, item)

    def _produto_selecionado(self):
        row = self.tabela.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um produto.")
            return None, None
        pid = int(self.tabela.item(row, 0).text())
        return pid, self.db.buscar_produto(pid)

    # ---------- Cadastrar ----------
    def cadastrar(self):
        nome = self.txt_nome.text().strip()
        if not nome:
            QMessageBox.warning(self, "Erro", "Informe o nome do produto.")
            return
        categoria = self.cmb_categoria.currentText().strip() or "Geral"
        self.db.adicionar_produto(
            nome, self.sp_preco.value(), self.sp_estoque.value(),
            categoria, "geral", self.sp_minimo.value()
        )
        self.txt_nome.clear()
        self.sp_preco.setValue(0)
        self.sp_estoque.setValue(0)
        self.sp_minimo.setValue(5)
        self.carregar()
        self.ao_mudar_produtos()

    # ---------- Editar ----------
    def editar(self):
        pid, produto = self._produto_selecionado()
        if not produto:
            return
        dlg = DialogEditarProduto(self.db, produto, self)
        if dlg.exec() == QDialog.Accepted:
            self.carregar()
            self.ao_mudar_produtos()

    # ---------- Excluir ----------
    def excluir(self):
        pid, produto = self._produto_selecionado()
        if not produto:
            return
        if msg_confirmar(self, "Confirmar",
                         f"Excluir o produto '{produto['nome']}'?"):
            self.db.excluir_produto(pid)
            self.carregar()
            self.ao_mudar_produtos()

    # ---------- Ajustes de estoque ----------
    def ajustar(self, sinal):
        pid, produto = self._produto_selecionado()
        if not produto:
            return
        qtd, ok = QInputDialog.getInt(
            self, "Ajustar estoque",
            f"Quantidade para {'adicionar' if sinal > 0 else 'remover'}:",
            1, 1, 9999
        )
        if not ok:
            return
        self.db.adicionar_estoque(pid, qtd * sinal)
        self.carregar()
        self.ao_mudar_produtos()

    def definir_valor(self):
        pid, produto = self._produto_selecionado()
        if not produto:
            return
        novo, ok = QInputDialog.getInt(
            self, "Definir estoque",
            f"Novo estoque para '{produto['nome']}':",
            produto["estoque"], 0, 999999
        )
        if not ok:
            return
        self.db.ajustar_estoque(pid, novo)
        self.carregar()
        self.ao_mudar_produtos()

# =========================================================
# PAGINA VENDAS (PDV do operador)
# =========================================================
class PaginaVendas(QWidget):
    def __init__(self, db: Database, ao_finalizar):
        super().__init__()
        self.db = db; self.ao_finalizar = ao_finalizar
        self.carrinho = []; self.categoria_atual = "Todas"
        self._build(); self.atualizar_disponiveis()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24); layout.setSpacing(16)
        layout.addWidget(titulo_pagina("Vendas (PDV)", "Filtre por categoria e clique em um produto."))

        corpo = QHBoxLayout(); corpo.setSpacing(16)

        esq = QFrame(); esq.setObjectName("card")
        lay_e = QVBoxLayout(esq); lay_e.setContentsMargins(16, 16, 16, 16); lay_e.setSpacing(10)

        self.txt_busca = QLineEdit(); self.txt_busca.setPlaceholderText("Buscar produto...")
        self.txt_busca.textChanged.connect(self.atualizar_disponiveis)
        lay_e.addWidget(self.txt_busca)

        self.chips_lay = QHBoxLayout(); self.chips_lay.setSpacing(8)
        self.btn_chips = {}
        for cat in ["Todas", "Bebidas", "Salgados", "Pratos", "Gelados"]:
            b = QPushButton(cat); b.setCheckable(True); b.setObjectName("navBtn")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _, c=cat: self._selecionar_categoria(c))
            self.chips_lay.addWidget(b); self.btn_chips[cat] = b
        self.chips_lay.addStretch()
        lay_e.addLayout(self.chips_lay)
        self.btn_chips["Todas"].setChecked(True)

        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        self.grid_widget = QWidget()
        self.grid = QGridLayout(self.grid_widget); self.grid.setSpacing(12)
        self.grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.grid_widget)
        lay_e.addWidget(self.scroll, 1)

        dir_ = QFrame(); dir_.setObjectName("card"); dir_.setFixedWidth(420)
        lay_d = QVBoxLayout(dir_); lay_d.setContentsMargins(16, 16, 16, 16); lay_d.setSpacing(10)
        lay_d.addWidget(QLabel("<b>Carrinho</b>"))
        self.tabela_cart = QTableWidget(0, 4)
        self.tabela_cart.setHorizontalHeaderLabels(["Produto", "Qtd", "Preco", "Subtotal"])
        self.tabela_cart.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela_cart.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela_cart.verticalHeader().setVisible(False)
        lay_d.addWidget(self.tabela_cart, 1)

        linha_acoes = QHBoxLayout()
        btn_mais = QPushButton("+"); btn_menos = QPushButton("-"); btn_remover = QPushButton("Remover")
        btn_mais.clicked.connect(lambda: self.alterar_qtd(1))
        btn_menos.clicked.connect(lambda: self.alterar_qtd(-1))
        btn_remover.clicked.connect(self.remover)
        linha_acoes.addWidget(btn_mais); linha_acoes.addWidget(btn_menos)
        linha_acoes.addWidget(btn_remover); linha_acoes.addStretch()
        lay_d.addLayout(linha_acoes)

        linha_pag = QHBoxLayout()
        linha_pag.addWidget(QLabel("Pagamento:"))
        self.cmb_pag = QComboBox()
        self.cmb_pag.addItems(["Dinheiro", "Cartao Debito", "Cartao Credito", "PIX", "Fiado"])
        linha_pag.addWidget(self.cmb_pag)
        lay_d.addLayout(linha_pag)

        linha_cli = QHBoxLayout()
        linha_cli.addWidget(QLabel("Cliente:"))
        self.txt_cliente_pdv = QLineEdit()
        self.txt_cliente_pdv.setPlaceholderText("Nome do cliente (opcional)")
        linha_cli.addWidget(self.txt_cliente_pdv)
        lay_d.addLayout(linha_cli)

        linha_total = QHBoxLayout(); linha_total.addStretch(); linha_total.addWidget(QLabel("Total:"))
        self.lbl_total = QLabel("R$ 0,00"); self.lbl_total.setObjectName("total")
        linha_total.addWidget(self.lbl_total)
        lay_d.addLayout(linha_total)

        btn_finalizar = QPushButton("Finalizar Venda"); btn_finalizar.setObjectName("success")
        btn_finalizar.setMinimumHeight(42); btn_finalizar.clicked.connect(self.finalizar)
        lay_d.addWidget(btn_finalizar)

        btn_limpar = QPushButton("Limpar Carrinho"); btn_limpar.setObjectName("ghost")
        btn_limpar.clicked.connect(self.limpar)
        lay_d.addWidget(btn_limpar)

        corpo.addWidget(esq, 1); corpo.addWidget(dir_)
        layout.addLayout(corpo)

    def _selecionar_categoria(self, cat):
        self.categoria_atual = cat
        for c, b in self.btn_chips.items():
            b.setChecked(c == cat)
        self.atualizar_disponiveis()

    def atualizar_disponiveis(self):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w: w.deleteLater()
        filtro = self.txt_busca.text().strip()
        produtos = self.db.listar_produtos(filtro, self.categoria_atual)
        colunas = 4; pos = 0
        for p in produtos:
            if p["estoque"] <= 0: continue
            card = CardProduto(p, self.adicionar_por_produto)
            r, c = divmod(pos, colunas)
            self.grid.addWidget(card, r, c); pos += 1

    def adicionar_por_produto(self, produto):
        item = next((i for i in self.carrinho if i["produto_id"] == produto["id"]), None)
        qtd_atual = item["quantidade"] if item else 0
        if qtd_atual + 1 > produto["estoque"]:
            QMessageBox.warning(self, "Estoque", f"Estoque disponivel: {produto['estoque']}"); return
        if item: item["quantidade"] += 1
        else:
            self.carrinho.append({"produto_id": produto["id"], "nome": produto["nome"],
                                  "quantidade": 1, "preco_unitario": produto["preco"]})
        self._atualizar()

    def alterar_qtd(self, delta):
        row = self.tabela_cart.currentRow()
        if row < 0: return
        item = self.carrinho[row]
        produto = self.db.buscar_produto(item["produto_id"])
        nova = item["quantidade"] + delta
        if nova <= 0: self.carrinho.pop(row)
        elif nova > produto["estoque"]:
            QMessageBox.warning(self, "Estoque", f"Estoque maximo: {produto['estoque']}"); return
        else: item["quantidade"] = nova
        self._atualizar()

    def remover(self):
        row = self.tabela_cart.currentRow()
        if row < 0: return
        self.carrinho.pop(row); self._atualizar()

    def limpar(self):
        if self.carrinho and msg_confirmar(self, "Limpar", "Limpar o carrinho?"):
            self.carrinho.clear(); self._atualizar()

    def _atualizar(self):
        self.tabela_cart.setRowCount(0); total = 0.0
        for item in self.carrinho:
            sub = item["quantidade"] * item["preco_unitario"]; total += sub
            r = self.tabela_cart.rowCount(); self.tabela_cart.insertRow(r)
            self.tabela_cart.setItem(r, 0, QTableWidgetItem(item["nome"]))
            self.tabela_cart.setItem(r, 1, QTableWidgetItem(str(item["quantidade"])))
            self.tabela_cart.setItem(r, 2, QTableWidgetItem(f"{item['preco_unitario']:.2f}"))
            self.tabela_cart.setItem(r, 3, QTableWidgetItem(f"{sub:.2f}"))
        self.lbl_total.setText(f"R$ {total:.2f}".replace(".", ","))

    def _gerar_pix(self, valor):
        if not PIX_DISPONIVEL:
            QMessageBox.critical(self, "Pix indisponivel", "Rode: pip install pixcore"); return None, None
        cfg = carregar_config()
        if not cfg.get("pix_chave", "").strip():
            QMessageBox.warning(self, "Pix nao configurado", "Peca ao administrador."); return None, None
        try:
            dados = PixData(recebedor_nome=cfg["pix_nome"].upper(),
                            recebedor_cidade=cfg["pix_cidade"].upper(),
                            pix_key=cfg["pix_chave"].strip(), valor=valor,
                            transacao_id=f"VENDA{datetime.now().strftime('%Y%m%d%H%M%S')}")
            gerador = Pix(dados)
            caminho_qr = os.path.join(os.path.dirname(__file__), "pix_temp.png")
            gerador.save_qrcode(caminho_qr)
            return caminho_qr, gerador.payload()
        except Exception as e:
            QMessageBox.critical(self, "Erro no Pix", f"Falha:\n{e}"); return None, None

    def _enviar_para_cozinha(self, total, forma, cliente_nome=""):
        itens_texto = " | ".join(f"{i['quantidade']}x {i['nome']}" for i in self.carrinho)
        try:
            pedidos.criar_pedido(itens_texto, total, forma, cliente_nome or "")
        except Exception as e:
            print(f"[PDV] Erro cozinha: {e}")

    def finalizar(self):
        if not self.carrinho:
            QMessageBox.warning(self, "Aviso", "Carrinho vazio."); return
        forma = self.cmb_pag.currentText()
        total = sum(i["quantidade"] * i["preco_unitario"] for i in self.carrinho)
        cliente_nome = self.txt_cliente_pdv.text().strip()

        if forma == "PIX":
            caminho_qr, payload = self._gerar_pix(total)
            if not caminho_qr: return
            dlg = DialogPix(caminho_qr, payload, total, self)
            if dlg.exec() != QDialog.Accepted: return

        if forma == "Fiado":
            if not cliente_nome:
                cliente_nome, ok = QInputDialog.getText(self, "Fiado", "Nome do cliente:")
                if not ok or not cliente_nome.strip(): return
                cliente_nome = cliente_nome.strip()
            cli = self.db.buscar_cliente(cliente_nome)
            if cli:
                limite, devedor, disp = self.db.limite_disponivel_cliente(cliente_nome)
                if total > disp:
                    QMessageBox.warning(self, "Limite excedido",
                        f"Cliente: {cliente_nome}\nLimite: R$ {limite:.2f}\nDevedor: R$ {devedor:.2f}\nDisponível: R$ {disp:.2f}")
                    return
            itens_desc = ", ".join(f"{i['quantidade']}x {i['nome']}" for i in self.carrinho)
            self.db.adicionar_fiado(cliente=cliente_nome, telefone="", produto=itens_desc,
                quantidade=sum(i["quantidade"] for i in self.carrinho), valor=total,
                observacao="Registrado pelo PDV")

        try:
            venda_id, total = self.db.registrar_venda(self.carrinho, forma, cliente_nome)
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha:\n{e}"); return

        self._enviar_para_cozinha(total, forma, cliente_nome)

        QMessageBox.information(self, "Venda registrada",
            f"Venda #{venda_id}\n\nTotal: R$ {total:.2f}\nPagamento: {forma}\n\nPedido enviado para a cozinha")

        self.carrinho.clear()
        self.txt_cliente_pdv.clear()
        self._atualizar()
        self.atualizar_disponiveis()
        self.ao_finalizar()

# =========================================================
# PAGINA HISTORICO
# =========================================================
class PaginaHistorico(QWidget):
    def __init__(self, db: Database):
        super().__init__()
        self.db = db
        self._build()
        self.carregar()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # ---------- Topo ----------
        topo = QHBoxLayout()
        topo.addWidget(titulo_pagina("Histórico de Vendas",
                                     "Consulte vendas por cliente, data ou pagamento."))
        topo.addStretch()

        btn_atualizar = QPushButton("Atualizar")
        btn_atualizar.setObjectName("primary")
        btn_atualizar.setMinimumHeight(40)
        btn_atualizar.setCursor(Qt.PointingHandCursor)
        btn_atualizar.clicked.connect(self.carregar)
        topo.addWidget(btn_atualizar, alignment=Qt.AlignTop)
        layout.addLayout(topo)

        # ---------- Barra de busca ----------
        busca_card = QFrame(); busca_card.setObjectName("card")
        busca_lay = QHBoxLayout(busca_card)
        busca_lay.setContentsMargins(16, 12, 16, 12)
        busca_lay.setSpacing(10)

        self.cmb_cliente = QComboBox()
        self.cmb_cliente.setEditable(True)
        self.cmb_cliente.setMinimumWidth(260)
        self.cmb_cliente.setPlaceholderText("Todos os clientes")
        self.cmb_cliente.lineEdit().setPlaceholderText("Buscar cliente...")
        self.cmb_cliente.currentTextChanged.connect(self.carregar)

        self.txt_busca = QLineEdit()
        self.txt_busca.setPlaceholderText("Filtrar por cliente, forma de pagamento ou data (AAAA-MM-DD)...")
        self.txt_busca.textChanged.connect(self.carregar)

        btn_limpar = QPushButton("Limpar filtros")
        btn_limpar.setObjectName("ghost")
        btn_limpar.setMinimumHeight(40)
        btn_limpar.setCursor(Qt.PointingHandCursor)
        btn_limpar.clicked.connect(self._limpar_filtros)

        busca_lay.addWidget(QLabel("Cliente:"))
        busca_lay.addWidget(self.cmb_cliente, 1)
        busca_lay.addWidget(self.txt_busca, 2)
        busca_lay.addWidget(btn_limpar)
        layout.addWidget(busca_card)

        # ---------- KPIs rápidos ----------
        kpi_lay = QHBoxLayout()
        kpi_lay.setSpacing(12)
        self.kpi_qtd   = self._kpi("Vendas exibidas", "0",        "#4f46e5")
        self.kpi_total = self._kpi("Total exibido",   "R$ 0,00",  "#10b981")
        kpi_lay.addWidget(self.kpi_qtd[0])
        kpi_lay.addWidget(self.kpi_total[0])
        kpi_lay.addStretch()
        layout.addLayout(kpi_lay)

        # ---------- Tabela de vendas ----------
        self.tabela = QTableWidget(0, 5)
        self.tabela.setHorizontalHeaderLabels(
            ["ID", "Data/Hora", "Cliente", "Pagamento", "Total (R$)"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.verticalHeader().setVisible(False)
        self.tabela.setMinimumHeight(260)
        layout.addWidget(self.tabela)

        # ---------- Resumo por dia ----------
        layout.addWidget(QLabel("<b>Resumo por dia</b>"))
        self.tabela_resumo = QTableWidget(0, 3)
        self.tabela_resumo.setHorizontalHeaderLabels(
            ["Dia", "Qtd de vendas", "Total (R$)"]
        )
        self.tabela_resumo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela_resumo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela_resumo.verticalHeader().setVisible(False)
        self.tabela_resumo.setMaximumHeight(200)
        layout.addWidget(self.tabela_resumo)

    # -----------------------------------------------------
    def _kpi(self, titulo, valor, cor):
        f = QFrame(); f.setObjectName("card")
        f.setMinimumHeight(80); f.setMinimumWidth(220)
        f.setStyleSheet(f"""
            QFrame#card {{
                background: {cor};
                border: none;
                border-radius: 14px;
            }}
            QLabel {{ color: white; background: transparent; }}
        """)
        lay = QVBoxLayout(f); lay.setContentsMargins(18, 12, 18, 12)
        lbl_t = QLabel(titulo.upper())
        lbl_t.setStyleSheet("font-size: 9pt; font-weight: 700; letter-spacing: 0.5px;")
        lbl_v = QLabel(valor)
        lbl_v.setStyleSheet("font-size: 18pt; font-weight: 800; color: white;")
        lay.addWidget(lbl_t); lay.addWidget(lbl_v)
        return f, lbl_v

    # -----------------------------------------------------
    def _limpar_filtros(self):
        self.txt_busca.blockSignals(True)
        self.cmb_cliente.blockSignals(True)
        self.txt_busca.clear()
        self.cmb_cliente.setCurrentText("")
        self.cmb_cliente.blockSignals(False)
        self.carregar()

    # -----------------------------------------------------
    def carregar(self):
        # Atualiza o combo com os clientes existentes (sem perder o texto digitado)
        texto_atual = self.cmb_cliente.currentText()
        self.cmb_cliente.blockSignals(True)
        self.cmb_cliente.clear()
        self.cmb_cliente.addItem("")  # opção "todos"
        for c in self.db.clientes_que_compraram():
            self.cmb_cliente.addItem(c)
        self.cmb_cliente.setCurrentText(texto_atual)
        self.cmb_cliente.blockSignals(False)

        filtro_cliente = self.cmb_cliente.currentText().strip()
        filtro_texto   = self.txt_busca.text().strip()

        vendas = self.db.listar_vendas(
            filtro_cliente=filtro_cliente,
            filtro_texto=filtro_texto,
        )

        # Preenche tabela
        self.tabela.setRowCount(0)
        for v in vendas:
            r = self.tabela.rowCount()
            self.tabela.insertRow(r)
            self.tabela.setItem(r, 0, QTableWidgetItem(str(v["id"])))
            self.tabela.setItem(r, 1, QTableWidgetItem(v["data"]))
            cliente = v.get("cliente") or "—"
            item_cli = QTableWidgetItem(cliente)
            if not v.get("cliente"):
                item_cli.setForeground(Qt.gray)
            self.tabela.setItem(r, 2, item_cli)
            self.tabela.setItem(r, 3, QTableWidgetItem(v["forma_pagamento"]))
            item_total = QTableWidgetItem(f"{v['total']:.2f}")
            item_total.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.tabela.setItem(r, 4, item_total)

        # KPIs
        total_exibido = sum(v["total"] for v in vendas)
        self.kpi_qtd[1].setText(str(len(vendas)))
        self.kpi_total[1].setText(f"R$ {total_exibido:.2f}".replace(".", ","))

        # Resumo por dia (respeitando o filtro)
        resumo = {}
        for v in vendas:
            dia = v["data"][:10]
            d = resumo.setdefault(dia, {"qtd": 0, "total": 0.0})
            d["qtd"] += 1
            d["total"] += v["total"]

        self.tabela_resumo.setRowCount(0)
        for dia in sorted(resumo.keys(), reverse=True):
            r = self.tabela_resumo.rowCount()
            self.tabela_resumo.insertRow(r)
            self.tabela_resumo.setItem(r, 0, QTableWidgetItem(dia))
            self.tabela_resumo.setItem(r, 1, QTableWidgetItem(str(resumo[dia]["qtd"])))
            self.tabela_resumo.setItem(
                r, 2, QTableWidgetItem(f"{resumo[dia]['total']:.2f}")
            )


# =========================================================
# PAGINA FIADOS
# =========================================================
class PaginaFiados(QWidget):
    def __init__(self, db: Database):
        super().__init__()
        self.db = db; self._kpi_widgets = []; self._build(); self.carregar()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24); layout.setSpacing(16)

        topo = QHBoxLayout()
        topo.addWidget(titulo_pagina("Fiados", "Clientes que ficaram devendo."))
        topo.addStretch()
        layout.addLayout(topo)

        kpis = QHBoxLayout(); kpis.setSpacing(14)
        self.kpi_total = self._criar_kpi("Total a receber", "R$ 0,00", "#dc2626")
        self.kpi_qtd = self._criar_kpi("Clientes devendo", "0", "#f59e0b")
        for w in self._kpi_widgets: kpis.addWidget(w)
        kpis.addStretch()
        layout.addLayout(kpis)

        acoes = QHBoxLayout()
        btn_novo = QPushButton("Registrar Fiado"); btn_novo.setObjectName("primary")
        btn_novo.clicked.connect(self.novo_fiado); acoes.addWidget(btn_novo)
        btn_pagar = QPushButton("Marcar como Pago"); btn_pagar.setObjectName("success")
        btn_pagar.clicked.connect(self.marcar_pago); acoes.addWidget(btn_pagar)
        btn_excluir = QPushButton("Excluir"); btn_excluir.setObjectName("danger")
        btn_excluir.clicked.connect(self.excluir); acoes.addWidget(btn_excluir)
        acoes.addStretch()
        self.cmb_mostrar = QComboBox()
        self.cmb_mostrar.addItems(["Apenas pendentes", "Todos (incluindo pagos)"])
        self.cmb_mostrar.currentIndexChanged.connect(self.carregar)
        acoes.addWidget(QLabel("Mostrar:")); acoes.addWidget(self.cmb_mostrar)
        layout.addLayout(acoes)

        self.txt_busca = QLineEdit(); self.txt_busca.setPlaceholderText("Buscar por cliente ou produto...")
        self.txt_busca.textChanged.connect(self.carregar)
        layout.addWidget(self.txt_busca)

        self.tabela = QTableWidget(0, 8)
        self.tabela.setHorizontalHeaderLabels(["ID", "Cliente", "Telefone", "Produto", "Qtd", "Valor", "Data", "Status"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela.verticalHeader().setVisible(False)
        layout.addWidget(self.tabela)

    def _criar_kpi(self, titulo, valor, cor):
        f = QFrame(); f.setObjectName("card"); f.setMinimumHeight(80); f.setMinimumWidth(260)
        f.setStyleSheet(f"""
            QFrame#card {{ background: {cor}; border: none; border-radius: 14px; }}
            QLabel {{ color: white; background: transparent; }}
        """)
        lay = QVBoxLayout(f); lay.setContentsMargins(18, 12, 18, 12)
        lbl_t = QLabel(titulo.upper()); lbl_t.setStyleSheet("font-size: 9pt; font-weight: 700;")
        lbl_v = QLabel(valor); lbl_v.setStyleSheet("font-size: 20pt; font-weight: 800; color: white;")
        lay.addWidget(lbl_t); lay.addWidget(lbl_v)
        self._kpi_widgets.append(f)
        return lbl_v

    def carregar(self):
        apenas = self.cmb_mostrar.currentIndex() == 0
        filtro = self.txt_busca.text().strip()
        fiados = self.db.listar_fiados(apenas_pendentes=apenas, filtro=filtro)
        self.tabela.setRowCount(0)
        for f in fiados:
            r = self.tabela.rowCount(); self.tabela.insertRow(r)
            self.tabela.setItem(r, 0, QTableWidgetItem(str(f["id"])))
            self.tabela.setItem(r, 1, QTableWidgetItem(f["cliente"]))
            self.tabela.setItem(r, 2, QTableWidgetItem(f["telefone"] or "-"))
            self.tabela.setItem(r, 3, QTableWidgetItem(f["produto"]))
            self.tabela.setItem(r, 4, QTableWidgetItem(str(f["quantidade"])))
            self.tabela.setItem(r, 5, QTableWidgetItem(f"{f['valor']:.2f}"))
            self.tabela.setItem(r, 6, QTableWidgetItem(f["data"]))
            status = "PAGO" if f["pago"] else "PENDENTE"
            item = QTableWidgetItem(status)
            item.setForeground(Qt.green if f["pago"] else Qt.red)
            self.tabela.setItem(r, 7, item)

        total = sum(f["valor"] for f in fiados if not f["pago"])
        clientes = len({f["cliente"] for f in fiados if not f["pago"]})
        self.kpi_total.setText(f"R$ {total:.2f}".replace(".", ","))
        self.kpi_qtd.setText(str(clientes))

    def novo_fiado(self):
        dlg = DialogNovoFiado(self)
        if dlg.exec():
            self.db.adicionar_fiado(**dlg.dados()); self.carregar()

    def marcar_pago(self):
        row = self.tabela.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um fiado."); return
        fid = int(self.tabela.item(row, 0).text())
        if msg_confirmar(self, "Confirmar", "Marcar como PAGO?"):
            self.db.marcar_fiado_pago(fid); self.carregar()

    def excluir(self):
        row = self.tabela.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um fiado."); return
        fid = int(self.tabela.item(row, 0).text())
        if msg_confirmar(self, "Confirmar", "Excluir este fiado?"):
            self.db.excluir_fiado(fid); self.carregar()


# =========================================================
# PAGINA CONFIGURACOES
# =========================================================
class PaginaConfiguracoes(QWidget):
    def __init__(self, db: Database, ao_salvar=None):
        super().__init__()
        self.db = db
        self.ao_salvar = ao_salvar
        self._build()
        self.carregar()

    def _build(self):
        # ---- Scroll externo (para caber em telas pequenas) ----
        raiz = QVBoxLayout(self)
        raiz.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        raiz.addWidget(scroll)

        conteudo = QWidget()
        scroll.setWidget(conteudo)

        layout = QVBoxLayout(conteudo)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        layout.addWidget(titulo_pagina(
            "Configurações (Admin)",
            "Pix, nome da loja, usuários e limites dos clientes."
        ))

        # =========================================================
        # CARD 1 — DADOS DO PIX
        # =========================================================
        card_pix = QFrame(); card_pix.setObjectName("card")
        lay_pix = QVBoxLayout(card_pix)
        lay_pix.setContentsMargins(24, 24, 24, 24)
        lay_pix.setSpacing(14)

        titulo_pix = QLabel("Dados do Pix")
        titulo_pix.setStyleSheet("font-size: 14pt; font-weight: 700; color: #4f46e5;")
        lay_pix.addWidget(titulo_pix)

        form = QFormLayout()
        form.setSpacing(12)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        self.txt_chave = QLineEdit()
        self.txt_chave.setPlaceholderText("CPF, CNPJ, e-mail, telefone ou chave aleatória")

        self.txt_nome = QLineEdit()
        self.txt_nome.setPlaceholderText("Nome do recebedor (até 25, sem acento)")

        self.txt_cidade = QLineEdit()
        self.txt_cidade.setPlaceholderText("Cidade (até 15, sem acento)")

        self.txt_loja = QLineEdit()
        self.txt_loja.setPlaceholderText("Nome no topo do sistema")

        form.addRow("Chave Pix:", self.txt_chave)
        form.addRow("Nome do recebedor:", self.txt_nome)
        form.addRow("Cidade:", self.txt_cidade)
        form.addRow("Nome da loja:", self.txt_loja)
        lay_pix.addLayout(form)

        # Botões FORA do QFormLayout (isso resolvia o corte do "Testar QR Code")
        botoes_pix = QHBoxLayout()
        btn_salvar = QPushButton("Salvar configurações")
        btn_salvar.setObjectName("primary")
        btn_salvar.setMinimumHeight(42)
        btn_salvar.setCursor(Qt.PointingHandCursor)
        btn_salvar.clicked.connect(self.salvar)

        btn_testar = QPushButton("Testar QR Code")
        btn_testar.setObjectName("ghost")
        btn_testar.setMinimumHeight(42)
        btn_testar.setCursor(Qt.PointingHandCursor)
        btn_testar.clicked.connect(self.testar)

        botoes_pix.addWidget(btn_salvar)
        botoes_pix.addWidget(btn_testar)
        botoes_pix.addStretch()
        lay_pix.addLayout(botoes_pix)

        layout.addWidget(card_pix)

        # =========================================================
        # CARD 2 — CLIENTES E LIMITES
        # =========================================================
        card_cli = QFrame(); card_cli.setObjectName("card")
        lay_cli = QVBoxLayout(card_cli)
        lay_cli.setContentsMargins(24, 24, 24, 24)
        lay_cli.setSpacing(12)

        titulo_cli = QLabel("Clientes e limites de fiado")
        titulo_cli.setStyleSheet("font-size: 14pt; font-weight: 700; color: #4f46e5;")
        lay_cli.addWidget(titulo_cli)

        self.txt_busca_cli = QLineEdit()
        self.txt_busca_cli.setPlaceholderText("Buscar cliente...")
        self.txt_busca_cli.textChanged.connect(self._carregar_clientes)
        lay_cli.addWidget(self.txt_busca_cli)

        self.tabela_cli = QTableWidget(0, 6)
        self.tabela_cli.setHorizontalHeaderLabels(
            ["ID", "Nome", "Telefone", "Limite", "Devedor", "Disponível"]
        )
        self.tabela_cli.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela_cli.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela_cli.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela_cli.verticalHeader().setVisible(False)
        self.tabela_cli.setMinimumHeight(240)
        lay_cli.addWidget(self.tabela_cli)

        # Botões EM LINHA SEPARADA, depois da tabela — com height fixo
        barra_cli = QHBoxLayout()
        barra_cli.setSpacing(10)
        btn_ml = QPushButton("Mudar limite")
        btn_ml.setObjectName("primary")
        btn_ml.setMinimumHeight(40)
        btn_ml.setCursor(Qt.PointingHandCursor)
        btn_ml.clicked.connect(self._mudar_limite)

        btn_ec = QPushButton("Excluir cliente")
        btn_ec.setObjectName("danger")
        btn_ec.setMinimumHeight(40)
        btn_ec.setCursor(Qt.PointingHandCursor)
        btn_ec.clicked.connect(self._excluir_cliente)

        barra_cli.addWidget(btn_ml)
        barra_cli.addWidget(btn_ec)
        barra_cli.addStretch()
        lay_cli.addLayout(barra_cli)

        layout.addWidget(card_cli)

        # =========================================================
        # CARD 3 — USUARIOS DO SISTEMA
        # =========================================================
        card_user = QFrame(); card_user.setObjectName("card")
        lay_user = QVBoxLayout(card_user)
        lay_user.setContentsMargins(24, 24, 24, 24)
        lay_user.setSpacing(12)

        titulo_user = QLabel("Usuários do sistema (admin / vendedor)")
        titulo_user.setStyleSheet("font-size: 14pt; font-weight: 700; color: #4f46e5;")
        lay_user.addWidget(titulo_user)

        # Linha de adicionar usuário
        linha_add = QHBoxLayout()
        linha_add.setSpacing(10)

        self.txt_novo_user = QLineEdit()
        self.txt_novo_user.setPlaceholderText("Novo usuário")

        self.txt_nova_senha = QLineEdit()
        self.txt_nova_senha.setPlaceholderText("Senha")
        self.txt_nova_senha.setEchoMode(QLineEdit.Password)

        self.cmb_tipo_user = QComboBox()
        self.cmb_tipo_user.addItems(["admin", "vendedor"])

        btn_add_u = QPushButton("Adicionar")
        btn_add_u.setObjectName("primary")
        btn_add_u.setMinimumHeight(40)
        btn_add_u.setCursor(Qt.PointingHandCursor)
        btn_add_u.clicked.connect(self.adicionar_usuario)

        linha_add.addWidget(self.txt_novo_user, 2)
        linha_add.addWidget(self.txt_nova_senha, 2)
        linha_add.addWidget(self.cmb_tipo_user, 1)
        linha_add.addWidget(btn_add_u)
        lay_user.addLayout(linha_add)

        self.tabela_users = QTableWidget(0, 3)
        self.tabela_users.setHorizontalHeaderLabels(["ID", "Usuário", "Tipo"])
        self.tabela_users.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tabela_users.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tabela_users.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tabela_users.verticalHeader().setVisible(False)
        self.tabela_users.setMinimumHeight(200)
        lay_user.addWidget(self.tabela_users)

        barra_user = QHBoxLayout()
        barra_user.setSpacing(10)

        btn_eu = QPushButton("Excluir usuário")
        btn_eu.setObjectName("danger")
        btn_eu.setMinimumHeight(40)
        btn_eu.setCursor(Qt.PointingHandCursor)
        btn_eu.clicked.connect(self.excluir_usuario)

        btn_ms = QPushButton("Mudar senha")
        btn_ms.setObjectName("ghost")
        btn_ms.setMinimumHeight(40)
        btn_ms.setCursor(Qt.PointingHandCursor)
        btn_ms.clicked.connect(self.mudar_senha)

        barra_user.addWidget(btn_eu)
        barra_user.addWidget(btn_ms)
        barra_user.addStretch()
        lay_user.addLayout(barra_user)

        layout.addWidget(card_user)
        layout.addStretch()

    # =====================================================
    # CARREGAR DADOS
    # =====================================================
    def carregar(self):
        cfg = carregar_config()
        self.txt_chave.setText(cfg.get("pix_chave", ""))
        self.txt_nome.setText(cfg.get("pix_nome", ""))
        self.txt_cidade.setText(cfg.get("pix_cidade", ""))
        self.txt_loja.setText(cfg.get("nome_loja", "LOJA PABLO"))
        self._carregar_usuarios()
        self._carregar_clientes()

    def _carregar_clientes(self):
        filtro = self.txt_busca_cli.text().strip()
        clientes = self.db.listar_clientes(filtro)
        self.tabela_cli.setRowCount(0)
        for c in clientes:
            limite, devedor, disp = self.db.limite_disponivel_cliente(c["nome"])
            r = self.tabela_cli.rowCount()
            self.tabela_cli.insertRow(r)
            self.tabela_cli.setItem(r, 0, QTableWidgetItem(str(c["id"])))
            self.tabela_cli.setItem(r, 1, QTableWidgetItem(c["nome"]))
            self.tabela_cli.setItem(r, 2, QTableWidgetItem(c.get("telefone") or "-"))
            self.tabela_cli.setItem(r, 3, QTableWidgetItem(f"{limite:.2f}"))
            self.tabela_cli.setItem(r, 4, QTableWidgetItem(f"{devedor:.2f}"))
            item = QTableWidgetItem(f"{disp:.2f}")
            item.setForeground(Qt.darkGreen if disp > 0 else Qt.red)
            self.tabela_cli.setItem(r, 5, item)

    def _carregar_usuarios(self):
        users = self.db.listar_usuarios()
        self.tabela_users.setRowCount(0)
        for u in users:
            r = self.tabela_users.rowCount()
            self.tabela_users.insertRow(r)
            self.tabela_users.setItem(r, 0, QTableWidgetItem(str(u["id"])))
            self.tabela_users.setItem(r, 1, QTableWidgetItem(u["usuario"]))
            self.tabela_users.setItem(r, 2, QTableWidgetItem(u["tipo"]))

    # =====================================================
    # ACOES — CLIENTES
    # =====================================================
    def _mudar_limite(self):
        row = self.tabela_cli.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente.")
            return
        nome = self.tabela_cli.item(row, 1).text()
        try:
            atual = float(self.tabela_cli.item(row, 3).text())
        except (ValueError, AttributeError):
            atual = 50.0
        novo, ok = QInputDialog.getDouble(
            self, "Mudar limite",
            f"Novo limite para '{nome}':",
            atual, 0, 999999, 2
        )
        if not ok:
            return
        self.db.atualizar_limite_cliente(nome, novo)
        self._carregar_clientes()
        QMessageBox.information(self, "OK", f"Limite de '{nome}' agora é R$ {novo:.2f}")

    def _excluir_cliente(self):
        row = self.tabela_cli.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente.")
            return
        cid = int(self.tabela_cli.item(row, 0).text())
        nome = self.tabela_cli.item(row, 1).text()
        if msg_confirmar(self, "Confirmar", f"Excluir o cliente '{nome}'?"):
            self.db.excluir_cliente(cid)
            self._carregar_clientes()

    # =====================================================
    # ACOES — USUARIOS
    # =====================================================
    def adicionar_usuario(self):
        user = self.txt_novo_user.text().strip()
        senha = self.txt_nova_senha.text().strip()
        tipo = self.cmb_tipo_user.currentText()
        if not user or not senha:
            QMessageBox.warning(self, "Erro", "Preencha usuário e senha.")
            return
        try:
            self.db.adicionar_usuario(user, senha, tipo)
            self.txt_novo_user.clear()
            self.txt_nova_senha.clear()
            self._carregar_usuarios()
            QMessageBox.information(self, "OK", f"Usuário '{user}' criado.")
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha:\n{e}")

    def excluir_usuario(self):
        row = self.tabela_users.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um usuário.")
            return
        uid = int(self.tabela_users.item(row, 0).text())
        nome = self.tabela_users.item(row, 1).text()
        if nome == "admin":
            QMessageBox.warning(self, "Erro", "Não é possível excluir o admin principal.")
            return
        if msg_confirmar(self, "Confirmar", f"Excluir usuário '{nome}'?"):
            self.db.excluir_usuario(uid)
            self._carregar_usuarios()

    def mudar_senha(self):
        row = self.tabela_users.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Aviso", "Selecione um usuário.")
            return
        uid = int(self.tabela_users.item(row, 0).text())
        nova, ok = QInputDialog.getText(
            self, "Nova senha", "Nova senha:", QLineEdit.Password
        )
        if ok and nova.strip():
            self.db.mudar_senha(uid, nova.strip())
            QMessageBox.information(self, "OK", "Senha alterada.")

    # =====================================================
    # ACOES — PIX
    # =====================================================
    def salvar(self):
        chave = self.txt_chave.text().strip()
        nome = self.txt_nome.text().strip().upper()
        cidade = self.txt_cidade.text().strip().upper()
        loja = self.txt_loja.text().strip() or "LOJA PABLO"
        if not chave:
            QMessageBox.warning(self, "Erro", "Informe a chave Pix.")
            return
        if not nome:
            QMessageBox.warning(self, "Erro", "Informe o nome do recebedor.")
            return
        if not cidade:
            QMessageBox.warning(self, "Erro", "Informe a cidade.")
            return
        salvar_config({
            "pix_chave": chave,
            "pix_nome": nome,
            "pix_cidade": cidade,
            "nome_loja": loja,
        })
        QMessageBox.information(self, "Salvo", "Configurações salvas!")
        if self.ao_salvar:
            self.ao_salvar()

    def testar(self):
        if not pix_configurado():
            QMessageBox.warning(self, "Teste", "Preencha e salve a chave Pix primeiro.")
            return
        try:
            if not PIX_DISPONIVEL:
                QMessageBox.critical(self, "Erro", "Instale: pip install pixcore")
                return
            cfg = carregar_config()
            dados = PixData(
                recebedor_nome=cfg["pix_nome"],
                recebedor_cidade=cfg["pix_cidade"],
                pix_key=cfg["pix_chave"],
                valor=1.00,
                transacao_id=f"TESTE{datetime.now().strftime('%Y%m%d%H%M%S')}"
            )
            gerador = Pix(dados)
            caminho_qr = os.path.join(os.path.dirname(__file__), "pix_teste.png")
            gerador.save_qrcode(caminho_qr)
            dlg = DialogPix(caminho_qr, gerador.payload(), 1.00, self)
            dlg.setWindowTitle("Teste de Pix - R$ 1,00")
            dlg.exec()
        except Exception as e:
            QMessageBox.critical(self, "Erro", f"Falha:\n{e}")

# =========================================================
# PAGINA FILA DE PEDIDOS (Cozinha)
# =========================================================
class PaginaFilaPedidos(QWidget):
    def __init__(self, tipo_usuario="vendedor"):
        super().__init__()
        self.tipo_usuario = tipo_usuario
        self._kpi_widgets = []
        self._build()
        self.carregar()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # ---------- Topo ----------
        topo = QHBoxLayout()
        topo.addWidget(titulo_pagina(
            "Fila de Pedidos",
            "Pedidos em espera para preparo na cozinha."
        ))
        topo.addStretch()

        btn_atualizar = QPushButton("Atualizar")
        btn_atualizar.setObjectName("primary")
        btn_atualizar.setMinimumHeight(40)
        btn_atualizar.setCursor(Qt.PointingHandCursor)
        btn_atualizar.clicked.connect(self.carregar)
        topo.addWidget(btn_atualizar, alignment=Qt.AlignTop)
        layout.addLayout(topo)

        # ---------- KPIs ----------
        kpi_lay = QHBoxLayout()
        kpi_lay.setSpacing(14)
        self.kpi_qtd    = self._kpi("Pedidos em espera", "0", "#f59e0b")
        self.kpi_antigo = self._kpi("Mais antigo (min)", "0", "#dc2626")
        for w in self._kpi_widgets:
            kpi_lay.addWidget(w)
        kpi_lay.addStretch()
        layout.addLayout(kpi_lay)

        # ---------- Ações extras ----------
        acoes = QHBoxLayout()
        btn_limpar = QPushButton("Limpar concluídos do arquivo")
        btn_limpar.setObjectName("ghost")
        btn_limpar.setMinimumHeight(38)
        btn_limpar.setCursor(Qt.PointingHandCursor)
        btn_limpar.clicked.connect(self._limpar_concluidos)
        acoes.addWidget(btn_limpar)
        acoes.addStretch()
        layout.addLayout(acoes)

        # ---------- Scroll de cards ----------
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        self.container = QWidget()
        self.grid = QGridLayout(self.container)
        self.grid.setSpacing(14)
        self.grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll.setWidget(self.container)
        layout.addWidget(self.scroll, 1)

        # ---------- Estado vazio ----------
        self.lbl_vazio = QLabel("🎉  Nenhum pedido em espera no momento.")
        self.lbl_vazio.setAlignment(Qt.AlignCenter)
        self.lbl_vazio.setStyleSheet("font-size: 16pt; color: #64748b; padding: 60px;")
        layout.addWidget(self.lbl_vazio)
        self.lbl_vazio.hide()

    def _kpi(self, titulo, valor, cor):
        f = QFrame(); f.setObjectName("card")
        f.setMinimumHeight(80); f.setMinimumWidth(220)
        f.setStyleSheet(f"""
            QFrame#card {{
                background: {cor};
                border: none;
                border-radius: 14px;
            }}
            QLabel {{ color: white; background: transparent; }}
        """)
        lay = QVBoxLayout(f); lay.setContentsMargins(18, 12, 18, 12)
        lbl_t = QLabel(titulo.upper())
        lbl_t.setStyleSheet("font-size: 9pt; font-weight: 700; letter-spacing: 0.5px;")
        lbl_v = QLabel(valor)
        lbl_v.setStyleSheet("font-size: 18pt; font-weight: 800; color: white;")
        lay.addWidget(lbl_t); lay.addWidget(lbl_v)
        self._kpi_widgets.append(f)
        return lbl_v

    def carregar(self):
        # Limpa o grid
        while self.grid.count():
            it = self.grid.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()

        try:
            pedidos_lista = pedidos_mod.listar_pedidos_em_espera()
        except Exception as e:
            print(f"[Fila] Erro ao ler pedidos: {e}")
            pedidos_lista = []

        pedidos_lista.sort(key=lambda p: p.get("id", 0))

        if not pedidos_lista:
            self.scroll.hide()
            self.lbl_vazio.show()
            self.kpi_qtd.setText("0")
            self.kpi_antigo.setText("0")
            return

        self.scroll.show()
        self.lbl_vazio.hide()

        minutos_max = 0
        for p in pedidos_lista:
            m = self._minutos_desde(p)
            if m > minutos_max:
                minutos_max = m

        self.kpi_qtd.setText(str(len(pedidos_lista)))
        self.kpi_antigo.setText(str(minutos_max))

        colunas = 3
        for i, p in enumerate(pedidos_lista):
            card = self._criar_card(p)
            r, c = divmod(i, colunas)
            self.grid.addWidget(card, r, c)

    def _minutos_desde(self, pedido):
        try:
            hora = pedido.get("hora", "00:00:00")
            h, m, s = [int(x) for x in hora.split(":")]
            agora = datetime.now()
            criado = agora.replace(hour=h, minute=m, second=s, microsecond=0)
            if criado > agora:
                criado = criado.replace(day=criado.day - 1)
            return int((agora - criado).total_seconds() // 60)
        except Exception:
            return 0

    def _criar_card(self, pedido):
        pid = pedido.get("id", "?")
        minutos = self._minutos_desde(pedido)

        if minutos >= 15:
            cor_borda = "#dc2626"; cor_fundo = "#fef2f2"
        elif minutos >= 8:
            cor_borda = "#f59e0b"; cor_fundo = "#fffbeb"
        else:
            cor_borda = "#10b981"; cor_fundo = "#f0fdf4"

        card = QFrame()
        card.setObjectName("cardPedido")
        card.setMinimumWidth(360)
        card.setMaximumWidth(420)
        card.setStyleSheet(f"""
            QFrame#cardPedido {{
                background: {cor_fundo};
                border: 2px solid {cor_borda};
                border-radius: 14px;
            }}
            QFrame#cardPedido QLabel {{
                background: transparent;
                color: #1e293b;
            }}
        """)

        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        topo = QHBoxLayout()
        lbl_id = QLabel(f"<b>Pedido #{pid}</b>")
        lbl_id.setStyleSheet("font-size: 13pt; color: #4f46e5;")
        topo.addWidget(lbl_id)
        topo.addStretch()
        lbl_tempo = QLabel(f"⏱ {minutos} min")
        lbl_tempo.setStyleSheet(f"font-size: 11pt; font-weight: 700; color: {cor_borda};")
        topo.addWidget(lbl_tempo)
        lay.addLayout(topo)

        linha_info = QHBoxLayout()
        cliente = pedido.get("cliente") or "—"
        lbl_cli = QLabel(f"👤 {cliente}")
        lbl_cli.setStyleSheet("font-size: 10pt; color: #64748b;")
        linha_info.addWidget(lbl_cli)
        linha_info.addStretch()
        lbl_hora = QLabel(f"🕒 {pedido.get('hora', '')}")
        lbl_hora.setStyleSheet("font-size: 10pt; color: #64748b;")
        linha_info.addWidget(lbl_hora)
        lay.addLayout(linha_info)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet(f"background: {cor_borda}; max-height: 1px;")
        lay.addWidget(sep)

        itens_txt = pedido.get("itens", "")
        lbl_itens = QLabel(itens_txt)
        lbl_itens.setWordWrap(True)
        lbl_itens.setStyleSheet(
            "font-size: 11pt; font-weight: 600; color: #1e293b; padding: 4px 0;"
        )
        lay.addWidget(lbl_itens)

        rodape = QHBoxLayout()
        forma = pedido.get("forma_pagamento", "")
        lbl_forma = QLabel(f"💳 {forma}")
        lbl_forma.setStyleSheet("font-size: 10pt; color: #64748b;")
        rodape.addWidget(lbl_forma)
        rodape.addStretch()
        total = pedido.get("total", 0.0)
        lbl_total = QLabel(f"R$ {total:.2f}".replace(".", ","))
        lbl_total.setStyleSheet("font-size: 12pt; font-weight: 800; color: #10b981;")
        rodape.addWidget(lbl_total)
        lay.addLayout(rodape)

        btn = QPushButton("✔  CONCLUÍDO")
        btn.setMinimumHeight(44)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setStyleSheet("""
            QPushButton {
                background: #10b981; color: white; border: none;
                border-radius: 10px; font-size: 12pt; font-weight: 800;
                letter-spacing: 1px;
            }
            QPushButton:hover { background: #059669; }
            QPushButton:pressed { background: #047857; }
        """)
        btn.clicked.connect(lambda _, p=pid: self._concluir(p))
        lay.addWidget(btn)

        return card

    def _concluir(self, pedido_id):
        if msg_confirmar(self, "Confirmar",
                         f"Marcar o pedido #{pedido_id} como concluído?",
                         "Ele sairá da fila da cozinha.",
                         sim="Sim, concluir", nao="Cancelar"):
            pedidos_mod.concluir_pedido(pedido_id)
            self.carregar()

    def _limpar_concluidos(self):
        if msg_confirmar(self, "Limpar arquivo",
                         "Remover todos os pedidos concluídos do arquivo?",
                         "Os pedidos em espera NÃO serão removidos."):
            pedidos_mod.limpar_concluidos()
            self.carregar()

# =========================================================
# JANELA PRINCIPAL / TOTEM
# =========================================================
class JanelaPrincipal(QMainWindow):
    def __init__(self, usuario_logado):
        super().__init__()
        self.usuario = usuario_logado
        self.tipo = usuario_logado["tipo"]
        self.cliente_nome = usuario_logado.get("cliente_nome")

        if self.tipo == "cliente":
            self._montar_totem_cliente()
            return

        self.setWindowTitle(f"Loja Pablo - {usuario_logado['usuario']} ({self.tipo})")
        self.resize(1350, 820)
        self.tema_escuro = False
        self.db = Database()

        central = QWidget(); central.setObjectName("central")
        self.setCentralWidget(central)
        raiz = QVBoxLayout(central)
        raiz.setContentsMargins(0, 0, 0, 0); raiz.setSpacing(0)

        # ---------- TOPO ----------
        topo = QFrame(); topo.setObjectName("topo"); topo.setFixedHeight(68)
        lay_topo = QHBoxLayout(topo)
        lay_topo.setContentsMargins(20, 8, 20, 8); lay_topo.setSpacing(6)

        cfg = carregar_config()
        logo = QLabel(cfg.get("nome_loja", "LOJA PABLO"))
        logo.setStyleSheet("""
            font-size: 13pt; color: #4f46e5; font-weight: 800;
            padding: 6px 14px; background: #eef2ff; border-radius: 10px;
        """)
        lay_topo.addWidget(logo); lay_topo.addSpacing(12)

        self.btn_home      = self._nav_btn(icone_home(), "Início")
        self.btn_fila      = self._nav_btn(icone_vendas(), "Fila de Pedidos")
        self.btn_produtos  = self._nav_btn(icone_produtos(), "Produtos & Estoque")
        self.btn_vendas    = self._nav_btn(icone_vendas(), "Vendas")
        self.btn_historico = self._nav_btn(icone_historico(), "Histórico")
        self.btn_fiados    = self._nav_btn(icone_dinheiro(), "Fiados")
        self.btn_config    = self._nav_btn(icone_home(), "Configurações")

        if self.tipo == "admin":
            botoes_visiveis = [
                self.btn_home,
                self.btn_fila,
                self.btn_produtos,
                self.btn_vendas,
                self.btn_historico,
                self.btn_fiados,
                self.btn_config,
            ]
        else:
            botoes_visiveis = [
                self.btn_home,
                self.btn_fila,
                self.btn_produtos,   # vendedor vê em modo leitura
                self.btn_vendas,
                self.btn_fiados,
            ]

        self.grupo_nav = QButtonGroup(self); self.grupo_nav.setExclusive(True)
        for i, b in enumerate(botoes_visiveis):
            self.grupo_nav.addButton(b, i); lay_topo.addWidget(b)

        lay_topo.addStretch()

        lbl_user = QLabel(f"👤 {usuario_logado['usuario']} ({self.tipo})")
        lbl_user.setStyleSheet("""
            color: #4f46e5; font-weight: 600; padding: 6px 12px;
            background: #eef2ff; border-radius: 8px;
        """)
        lay_topo.addWidget(lbl_user)

        btn_sair = QPushButton("Sair"); btn_sair.setObjectName("ghost")
        btn_sair.clicked.connect(self.close); lay_topo.addWidget(btn_sair)

        self.btn_tema = QPushButton(); self.btn_tema.setObjectName("icone")
        self.btn_tema.setIcon(svg_icon(icone_lua(), 20))
        self.btn_tema.setIconSize(QSize(20, 20))
        self.btn_tema.clicked.connect(self._alternar_tema)
        lay_topo.addWidget(self.btn_tema)
        raiz.addWidget(topo)

        # ---------- PÁGINAS ----------
        self.stack = QStackedWidget()
        self.pagina_home   = PaginaInicial(self.ir_para_por_nome, self.tipo)
        self.pagina_fila   = PaginaFilaPedidos(self.tipo)
        self.pagina_vendas = PaginaVendas(self.db, self._ao_finalizar_venda)
        self.pagina_fiados = PaginaFiados(self.db)

        # Unificada: Produtos + Estoque
        self.pagina_produtos_estoque = PaginaProdutosEstoque(
            self.db, self._ao_mudar_produtos, self.tipo
        )

        if self.tipo == "admin":
            self.pagina_historico = PaginaHistorico(self.db)
            self.pagina_config    = PaginaConfiguracoes(self.db, ao_salvar=self._ao_salvar_config)

            for p in (
                self.pagina_home,
                self.pagina_fila,
                self.pagina_produtos_estoque,
                self.pagina_vendas,
                self.pagina_historico,
                self.pagina_fiados,
                self.pagina_config,
            ):
                self.stack.addWidget(p)
        else:
            for p in (
                self.pagina_home,
                self.pagina_fila,
                self.pagina_produtos_estoque,
                self.pagina_vendas,
                self.pagina_fiados,
            ):
                self.stack.addWidget(p)

        raiz.addWidget(self.stack, 1)

        # ---------- RODAPÉ ----------
        rodape = QFrame(); rodape.setObjectName("rodape"); rodape.setFixedHeight(36)
        lay_rod = QHBoxLayout(rodape); lay_rod.setContentsMargins(20, 0, 20, 0)
        self.lbl_status = QLabel("Pronto."); self.lbl_status.setObjectName("status")
        lay_rod.addWidget(self.lbl_status); lay_rod.addStretch()
        badge = QLabel(f"v6.2  |  {self.tipo.upper()}  |  Cozinha via arquivo")
        badge.setObjectName("badge"); lay_rod.addWidget(badge)
        raiz.addWidget(rodape)

        # ---------- NAVEGAÇÃO ----------
        self.grupo_nav.idClicked.connect(self.ir_para_indice)
        self.btn_home.setChecked(True)
        self.ir_para_indice(0)
        self.setStyleSheet(STYLESHEET)

    # -----------------------------------------------------
    # TOTEM DO CLIENTE (inalterado)
    # -----------------------------------------------------
    def _montar_totem_cliente(self):
        self.setWindowTitle(f"Loja Pablo - Bem-vindo, {self.cliente_nome}")
        self.showMaximized()

        db = Database()
        central = QWidget(); central.setObjectName("central")
        self.setCentralWidget(central)
        raiz = QVBoxLayout(central)
        raiz.setContentsMargins(0, 0, 0, 0); raiz.setSpacing(0)

        topo = QFrame(); topo.setObjectName("topo"); topo.setFixedHeight(70)
        lt = QHBoxLayout(topo); lt.setContentsMargins(24, 8, 24, 8)

        logo = QLabel("🛒  LOJA PABLO")
        logo.setStyleSheet("""
            font-size: 16pt; color: #4f46e5; font-weight: 900;
            padding: 6px 16px; background: #eef2ff; border-radius: 12px;
        """)
        lt.addWidget(logo); lt.addStretch()

        bem = QLabel(f"👤 {self.cliente_nome}")
        bem.setStyleSheet("""
            color: #4f46e5; font-weight: 700; padding: 8px 14px;
            background: #eef2ff; border-radius: 10px; font-size: 11pt;
        """)
        lt.addWidget(bem)

        btn_voltar = QPushButton("↩  Voltar ao início")
        btn_voltar.setObjectName("ghost"); btn_voltar.setMinimumHeight(42)
        btn_voltar.setCursor(Qt.PointingHandCursor)
        btn_voltar.clicked.connect(self._voltar_ao_login)
        lt.addWidget(btn_voltar)

        if not self.usuario.get("cadastrado", False):
            btn_reg = QPushButton("💳  Registrar fiado")
            btn_reg.setStyleSheet("""
                background: #f59e0b; color: white; border: none;
                border-radius: 10px; padding: 10px 18px;
                font-size: 11pt; font-weight: 800;
            """)
            btn_reg.setMinimumHeight(42)
            btn_reg.setCursor(Qt.PointingHandCursor)
            btn_reg.clicked.connect(self._registrar_fiado)
            lt.addWidget(btn_reg)

        raiz.addWidget(topo)

        if not self.usuario.get("cadastrado", False):
            aviso = QFrame()
            aviso.setStyleSheet("background: #fffbeb; border-bottom: 1px solid #fcd34d;")
            av = QHBoxLayout(aviso); av.setContentsMargins(24, 10, 24, 10)
            lbl = QLabel(
                "⚠️  Você ainda não tem cadastro. Pode comprar pagando normalmente. "
                "Para comprar fiado, clique em <b>Registrar fiado</b> acima."
            )
            lbl.setStyleSheet("color: #92400e; font-size: 10.5pt;")
            av.addWidget(lbl); av.addStretch()
            raiz.addWidget(aviso)

        self.totem = TotemCliente(
            db, self.cliente_nome,
            ao_sair=self.close,
            ao_atualizar_saldo=lambda: None,
            cadastrado=self.usuario.get("cadastrado", False)
        )
        raiz.addWidget(self.totem, 1)
        self.setStyleSheet(STYLESHEET)

    def _voltar_ao_login(self):
        self.close()
        db = Database()
        login = TelaLogin(db)
        if login.exec() == QDialog.Accepted:
            self.nova_janela = JanelaPrincipal(login.usuario_logado)
            self.nova_janela.show()

    def _registrar_fiado(self):
        dlg = DialogCadastroCliente(Database(), self)
        if dlg.exec() == QDialog.Accepted:
            self.usuario["cadastrado"] = True
            QMessageBox.information(self, "Pronto!",
                "Cadastro feito! Agora você já pode usar o fiado.")
            self.close()
            nova = JanelaPrincipal(self.usuario)
            nova.show()

    # -----------------------------------------------------
    # HELPERS DE NAVEGAÇÃO
    # -----------------------------------------------------
    def _nav_btn(self, icone_svg, texto):
        b = QPushButton(f"  {texto}")
        b.setObjectName("navBtn")
        b.setCheckable(True)
        b.setCursor(Qt.PointingHandCursor)
        b.setMinimumHeight(44)
        b.setIcon(svg_icon(icone_svg, 18))
        b.setIconSize(QSize(18, 18))
        return b

    def ir_para_por_nome(self, nome):
        mapa_admin = {
            "home": 0,
            "fila": 1,
            "produtos": 2,
            "vendas": 3,
            "historico": 4,
            "fiados": 5,
            "config": 6,
        }
        mapa_vend = {
            "home": 0,
            "fila": 1,
            "produtos": 2,
            "vendas": 3,
            "fiados": 4,
        }
        mapa = mapa_admin if self.tipo == "admin" else mapa_vend
        if nome in mapa:
            self.ir_para_indice(mapa[nome])

    def ir_para_indice(self, indice: int):
        self.stack.setCurrentIndex(indice)
        botoes = list(self.grupo_nav.buttons())
        if 0 <= indice < len(botoes):
            botoes[indice].setChecked(True)

        pagina = self.stack.currentWidget()
        if hasattr(pagina, "carregar"):
            try:
                pagina.carregar()
            except Exception:
                pass

        if pagina == self.pagina_home:
            self.pagina_home.atualizar_kpis(self.db)
        if pagina == self.pagina_vendas:
            self.pagina_vendas.atualizar_disponiveis()
        if pagina == self.pagina_fila:
            self.pagina_fila.carregar()

        self._status("Pronto")

    def _status(self, txt):
        self.lbl_status.setText(txt)

    def _alternar_tema(self):
        self.tema_escuro = not self.tema_escuro
        if self.tema_escuro:
            self.setStyleSheet(TEMA_ESCURO)
            self.btn_tema.setIcon(svg_icon(icone_sol(), 20))
        else:
            self.setStyleSheet(STYLESHEET)
            self.btn_tema.setIcon(svg_icon(icone_lua(), 20))

    # -----------------------------------------------------
    # CALLBACKS
    # -----------------------------------------------------
    def _ao_mudar_produtos(self):
        self.pagina_vendas.atualizar_disponiveis()
        self.pagina_home.atualizar_kpis(self.db)

    def _ao_finalizar_venda(self):
        if self.tipo == "admin":
            self.pagina_produtos_estoque.carregar()
            self.pagina_historico.carregar()
        self.pagina_home.atualizar_kpis(self.db)
        try:
            self.pagina_fila.carregar()
        except Exception:
            pass
        self._status("Venda registrada e enviada para a cozinha")

    def _ao_salvar_config(self):
        self._status("Configurações salvas")


# =========================================================
# MAIN
# =========================================================
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet("""
        QMessageBox { background-color: white; }
        QMessageBox QLabel { color: #1e293b; font-size: 11pt; }
        QMessageBox QPushButton {
            background-color: #4f46e5; color: white; border: none;
            border-radius: 8px; padding: 8px 18px; min-width: 90px; font-weight: 700;
        }
        QMessageBox QPushButton:hover { background-color: #4338ca; }
    """)

    garantir_imagens()

    db = Database()
    login = TelaLogin(db)
    if login.exec() != QDialog.Accepted:
        sys.exit(0)

    janela = JanelaPrincipal(login.usuario_logado)
    janela.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
