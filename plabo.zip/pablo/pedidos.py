import json
import os
from datetime import datetime


# =====================================================
# CAMINHO DA PASTA COMPARTILHADA (Google Drive)
# =====================================================
# ⚠️ MUDE AQUI para o caminho real da pasta do seu Google Drive
PASTA_DRIVE = r"C:\Users\cj3033791\Desktop\POOS\Python\Bim 3 Trabalho Aula 12  29'09'2026\pablo"

ARQUIVO_PEDIDOS = os.path.join(PASTA_DRIVE, "pedidos.txt")


def _garantir_pasta():
    try:
        os.makedirs(PASTA_DRIVE, exist_ok=True)
    except Exception:
        pass


def _ler_todos():
    _garantir_pasta()
    if not os.path.exists(ARQUIVO_PEDIDOS):
        return []
    try:
        with open(ARQUIVO_PEDIDOS, "r", encoding="utf-8") as f:
            conteudo = f.read().strip()
        if not conteudo:
            return []
        pedidos = []
        for linha in conteudo.splitlines():
            linha = linha.strip()
            if linha:
                try:
                    pedidos.append(json.loads(linha))
                except Exception:
                    pass
        return pedidos
    except Exception:
        return []


def _salvar_todos(pedidos):
    _garantir_pasta()
    with open(ARQUIVO_PEDIDOS, "w", encoding="utf-8") as f:
        for p in pedidos:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")


def criar_pedido(itens_texto, total, forma_pagamento, cliente=""):
    pedidos = _ler_todos()
    prox_id = max([p.get("id", 0) for p in pedidos], default=0) + 1
    pedido = {
        "id": prox_id,
        "hora": datetime.now().strftime("%H:%M:%S"),
        "data": datetime.now().strftime("%d/%m/%Y"),
        "itens": itens_texto,
        "total": round(total, 2),
        "forma_pagamento": forma_pagamento,
        "cliente": cliente or "",
        "status": "espera",
    }
    pedidos.append(pedido)
    _salvar_todos(pedidos)
    return prox_id


# =====================================================
# NOVAS FUNÇÕES — FILA DE PEDIDOS
# =====================================================
def listar_pedidos_em_espera():
    """Retorna todos os pedidos com status 'espera' (ordem de criação)."""
    return [p for p in _ler_todos() if p.get("status") == "espera"]


def listar_todos_pedidos():
    return _ler_todos()


def concluir_pedido(pedido_id):
    """Marca o pedido como concluído e o remove da fila em espera."""
    pedidos = _ler_todos()
    for p in pedidos:
        if p.get("id") == pedido_id:
            p["status"] = "concluido"
            p["hora_conclusao"] = datetime.now().strftime("%H:%M:%S")
            _salvar_todos(pedidos)
            return True
    return False


def excluir_pedido(pedido_id):
    """Remove completamente o pedido do arquivo (uso administrativo)."""
    pedidos = [p for p in _ler_todos() if p.get("id") != pedido_id]
    _salvar_todos(pedidos)


def limpar_concluidos():
    """Remove do arquivo todos os pedidos já concluídos."""
    pedidos = [p for p in _ler_todos() if p.get("status") != "concluido"]
    _salvar_todos(pedidos)

def listar_pedidos_em_espera():
    return [p for p in _ler_todos() if p.get("status") == "espera"]


def listar_todos_pedidos():
    return _ler_todos()


def concluir_pedido(pedido_id):
    pedidos = _ler_todos()
    for p in pedidos:
        if p.get("id") == pedido_id:
            p["status"] = "concluido"
            p["hora_conclusao"] = datetime.now().strftime("%H:%M:%S")
            _salvar_todos(pedidos)
            return True
    return False


def limpar_concluidos():
    pedidos = [p for p in _ler_todos() if p.get("status") != "concluido"]
    _salvar_todos(pedidos)