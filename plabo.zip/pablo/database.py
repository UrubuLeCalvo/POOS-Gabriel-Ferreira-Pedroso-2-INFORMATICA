import sqlite3
from datetime import datetime
from contextlib import contextmanager


class Database:
    def __init__(self, db_path="vendas.db"):
        self.db_path = db_path
        self._criar_tabelas()
        self._popular_se_vazio()
        self._popular_usuarios_padrao()

    @contextmanager
    def _conectar(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # =====================================================
    # CRIAÇÃO DAS TABELAS
    # =====================================================
    def _criar_tabelas(self):
        with self._conectar() as conn:
            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS produtos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    preco REAL NOT NULL,
                    estoque INTEGER NOT NULL DEFAULT 0,
                    estoque_minimo INTEGER NOT NULL DEFAULT 5,
                    categoria TEXT NOT NULL DEFAULT 'Geral',
                    imagem TEXT DEFAULT ''
                )
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS vendas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    data TEXT NOT NULL,
                    total REAL NOT NULL,
                    forma_pagamento TEXT NOT NULL,
                    cliente TEXT DEFAULT ''
                )
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS itens_venda (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    venda_id INTEGER NOT NULL,
                    produto_id INTEGER NOT NULL,
                    nome_produto TEXT NOT NULL,
                    quantidade INTEGER NOT NULL,
                    preco_unitario REAL NOT NULL,
                    subtotal REAL NOT NULL,
                    FOREIGN KEY (venda_id) REFERENCES vendas(id)
                )
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS fiados (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cliente TEXT NOT NULL,
                    telefone TEXT DEFAULT '',
                    produto TEXT NOT NULL,
                    quantidade INTEGER NOT NULL DEFAULT 1,
                    valor REAL NOT NULL,
                    data TEXT NOT NULL,
                    pago INTEGER NOT NULL DEFAULT 0,
                    data_pagamento TEXT DEFAULT '',
                    observacao TEXT DEFAULT ''
                )
            """)

            cur.execute("PRAGMA table_info(vendas)")
            colunas = [r[1] for r in cur.fetchall()]
            if "cliente" not in colunas:
                cur.execute("ALTER TABLE vendas ADD COLUMN cliente TEXT DEFAULT ''")

            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    usuario TEXT NOT NULL UNIQUE,
                    senha TEXT NOT NULL,
                    tipo TEXT NOT NULL DEFAULT 'vendedor'
                )
            """)

            # ---------- NOVO: CLIENTES (login + limite de fiado) ----------
            cur.execute("""
                CREATE TABLE IF NOT EXISTS clientes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL UNIQUE,
                    telefone TEXT DEFAULT '',
                    limite REAL NOT NULL DEFAULT 50.0,
                    senha TEXT DEFAULT ''
                )
            """)

            # ---------- NOVO: PEDIDOS FEITOS NO TOTEM ----------
            cur.execute("""
                CREATE TABLE IF NOT EXISTS pedidos_cliente (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cliente TEXT NOT NULL,
                    itens TEXT NOT NULL,
                    total REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'aguardando_pagamento',
                    data TEXT NOT NULL
                )
            """)

    # =====================================================
    # POPULA SE VAZIO
    # =====================================================
    def _popular_se_vazio(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM produtos")
            if cur.fetchone()[0] > 0:
                return

            produtos = [
                ("Guarana 350ml",                  5.50, 50, 5, "Bebidas",  "refri"),
                ("Fanta Uva 350ml",                5.50, 50, 5, "Bebidas",  "refri"),
                ("Fanta Laranja 350ml",            5.50, 50, 5, "Bebidas",  "refri"),
                ("Coca-Cola Zero 350ml",           5.50, 50, 5, "Bebidas",  "refri"),
                ("Coca-Cola 350ml",                5.50, 50, 5, "Bebidas",  "refri"),
                ("Suco Tropical 480ml",            8.00, 30, 5, "Bebidas",  "suco"),
                ("Suco Kmais 300ml",               7.50, 30, 5, "Bebidas",  "suco"),
                ("Refrigerante Cacula 200ml",      3.50, 50, 5, "Bebidas",  "refri"),
                ("Croissant Apresuntado e Queijo", 7.00, 20, 5, "Salgados", "croissant"),
                ("Risole de 4 Queijos",            5.50, 25, 5, "Salgados", "risole"),
                ("Risole de Carne",                5.50, 25, 5, "Salgados", "risole"),
                ("Croissant 3 Queijos",            6.50, 20, 5, "Salgados", "croissant"),
                ("Hamburguer com Cheddar",         7.00, 20, 5, "Salgados", "hamburguer"),
                ("Enroladinho de Bauru",           7.00, 20, 5, "Salgados", "enroladinho"),
                ("Pao de Batata com Calabresa",    6.50, 20, 5, "Salgados", "pao"),
                ("Pao de Batata de Frango",        6.50, 20, 5, "Salgados", "pao"),
                ("Esfiha de Carne",                7.00, 20, 5, "Salgados", "esfiha"),
                ("Coxinha",                        5.50, 30, 5, "Salgados", "coxinha"),
                ("Pao de Queijo",                  3.50, 40, 5, "Salgados", "pao"),
                ("Caldo (Mandioca/Abobora/Verde/Feijao)", 20.00, 10, 3, "Pratos", "caldo"),
                ("Espeto (Carne/Medalhao/Coracao)",       9.00, 20, 3, "Pratos", "espeto"),
                ("Acai 300ml",                     12.00, 20, 5, "Gelados", "gelado"),
                ("Sorvete Casquinha",              6.00, 30, 5, "Gelados", "gelado"),
                ("Milk Shake 400ml",               14.00, 15, 3, "Gelados", "gelado"),
            ]
            cur.executemany(
                """INSERT INTO produtos
                   (nome, preco, estoque, estoque_minimo, categoria, imagem)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                produtos,
            )

    def _popular_usuarios_padrao(self):
        """Cria os usuarios padrao se nao existirem."""
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM usuarios")
            if cur.fetchone()[0] == 0:
                cur.executemany(
                    "INSERT INTO usuarios (usuario, senha, tipo) VALUES (?, ?, ?)",
                    [
                        ("admin", "1234", "admin"),
                        ("vendedor", "1234", "vendedor"),
                    ],
                )

    # =====================================================
    # PRODUTOS
    # =====================================================
    def listar_produtos(self, filtro="", categoria=None):
        with self._conectar() as conn:
            cur = conn.cursor()
            sql = "SELECT * FROM produtos WHERE 1=1"
            params = []
            if filtro:
                sql += " AND nome LIKE ?"
                params.append(f"%{filtro}%")
            if categoria and categoria != "Todas":
                sql += " AND categoria = ?"
                params.append(categoria)
            sql += " ORDER BY categoria, nome"
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    def listar_categorias(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT DISTINCT categoria FROM produtos ORDER BY categoria")
            return [r[0] for r in cur.fetchall()]

    def buscar_produto(self, produto_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM produtos WHERE id = ?", (produto_id,))
            row = cur.fetchone()
            return dict(row) if row else None

    def adicionar_produto(self, nome, preco, estoque, categoria="Geral",
                          imagem="", estoque_minimo=5):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute(
                """INSERT INTO produtos
                   (nome, preco, estoque, estoque_minimo, categoria, imagem)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (nome, preco, estoque, estoque_minimo, categoria, imagem),
            )
            return cur.lastrowid

    def atualizar_produto(self, produto_id, nome, preco, estoque, categoria="Geral"):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE produtos SET nome=?, preco=?, estoque=?, categoria=? WHERE id=?",
                        (nome, preco, estoque, categoria, produto_id))

    def ajustar_estoque(self, produto_id, novo_valor):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE produtos SET estoque=? WHERE id=?", (novo_valor, produto_id))

    def adicionar_estoque(self, produto_id, quantidade):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE produtos SET estoque = estoque + ? WHERE id=?",
                        (quantidade, produto_id))

    def excluir_produto(self, produto_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM produtos WHERE id=?", (produto_id,))

    def produtos_estoque_baixo(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""SELECT * FROM produtos WHERE estoque <= estoque_minimo
                           ORDER BY (estoque - estoque_minimo), nome""")
            return [dict(r) for r in cur.fetchall()]

    # =====================================================
    # VENDAS
    # =====================================================
    def registrar_venda(self, itens, forma_pagamento, cliente=""):
        total = sum(i["quantidade"] * i["preco_unitario"] for i in itens)
        data = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO vendas (data, total, forma_pagamento, cliente) VALUES (?, ?, ?, ?)",
                (data, total, forma_pagamento, cliente or "")
            )
            venda_id = cur.lastrowid
            for item in itens:
                subtotal = item["quantidade"] * item["preco_unitario"]
                cur.execute("""INSERT INTO itens_venda
                    (venda_id, produto_id, nome_produto, quantidade, preco_unitario, subtotal)
                    VALUES (?, ?, ?, ?, ?, ?)""",
                    (venda_id, item["produto_id"], item["nome"],
                     item["quantidade"], item["preco_unitario"], subtotal))
                cur.execute("UPDATE produtos SET estoque = estoque - ? WHERE id = ?",
                            (item["quantidade"], item["produto_id"]))
            return venda_id, total

    def listar_vendas(self, filtro_cliente="", filtro_texto=""):
        with self._conectar() as conn:
            cur = conn.cursor()
            sql = "SELECT * FROM vendas WHERE 1=1"
            params = []
            if filtro_cliente:
                sql += " AND cliente LIKE ?"
                params.append(f"%{filtro_cliente}%")
            if filtro_texto:
                sql += " AND (cliente LIKE ? OR forma_pagamento LIKE ? OR data LIKE ?)"
                params += [f"%{filtro_texto}%", f"%{filtro_texto}%", f"%{filtro_texto}%"]
            sql += " ORDER BY id DESC"
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    def clientes_que_compraram(self):
        """Retorna a lista de clientes distintos que aparecem em vendas."""
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT DISTINCT cliente FROM vendas
                WHERE cliente IS NOT NULL AND cliente <> ''
                ORDER BY cliente
            """)
            return [r[0] for r in cur.fetchall()]

    def itens_da_venda(self, venda_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM itens_venda WHERE venda_id=?", (venda_id,))
            return [dict(r) for r in cur.fetchall()]

    def relatorio_vendas_por_dia(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""
                SELECT DATE(data) as dia, COUNT(*) as qtd, SUM(total) as total
                FROM vendas GROUP BY DATE(data) ORDER BY dia DESC
            """)
            return [dict(r) for r in cur.fetchall()]

           

    # =====================================================
    # FIADOS
    # =====================================================
    def adicionar_fiado(self, cliente, telefone, produto, quantidade,
                        valor, observacao=""):
        data = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""INSERT INTO fiados
                (cliente, telefone, produto, quantidade, valor, data, pago, observacao)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?)""",
                (cliente, telefone, produto, quantidade, valor, data, observacao))
            return cur.lastrowid

    def listar_fiados(self, apenas_pendentes=True, filtro=""):
        with self._conectar() as conn:
            cur = conn.cursor()
            sql = "SELECT * FROM fiados WHERE 1=1"
            params = []
            if apenas_pendentes:
                sql += " AND pago = 0"
            if filtro:
                sql += " AND (cliente LIKE ? OR produto LIKE ?)"
                params += [f"%{filtro}%", f"%{filtro}%"]
            sql += " ORDER BY pago, data DESC"
            cur.execute(sql, params)
            return [dict(r) for r in cur.fetchall()]

    def marcar_fiado_pago(self, fiado_id):
        data = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE fiados SET pago=1, data_pagamento=? WHERE id=?",
                        (data, fiado_id))

    def excluir_fiado(self, fiado_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM fiados WHERE id=?", (fiado_id,))

    def total_fiados_pendentes(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COALESCE(SUM(valor), 0) FROM fiados WHERE pago = 0")
            return cur.fetchone()[0]

    # =====================================================
    # USUARIOS DO SISTEMA (admin/vendedor)
    # =====================================================
    def autenticar(self, usuario, senha):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM usuarios WHERE usuario=? AND senha=?",
                        (usuario, senha))
            row = cur.fetchone()
            return dict(row) if row else None

    def listar_usuarios(self):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM usuarios ORDER BY usuario")
            return [dict(r) for r in cur.fetchall()]

    def adicionar_usuario(self, usuario, senha, tipo="vendedor"):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("INSERT INTO usuarios (usuario, senha, tipo) VALUES (?, ?, ?)",
                        (usuario, senha, tipo))
            return cur.lastrowid

    def excluir_usuario(self, usuario_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM usuarios WHERE id=?", (usuario_id,))

    def mudar_senha(self, usuario_id, nova_senha):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE usuarios SET senha=? WHERE id=?", (nova_senha, usuario_id))

    # =====================================================
    # CLIENTES (login + limite de fiado)
    # =====================================================
    def autenticar_cliente(self, nome, senha):
        """Login do cliente: procura em clientes por nome + senha."""
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM clientes WHERE nome=? AND senha=?",
                        (nome, senha))
            row = cur.fetchone()
            return dict(row) if row else None

    def adicionar_cliente(self, nome, telefone="", limite=50.0, senha=""):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""INSERT INTO clientes (nome, telefone, limite, senha)
                           VALUES (?, ?, ?, ?)""",
                        (nome, telefone, limite, senha))
            return cur.lastrowid

    def listar_clientes(self, filtro=""):
        with self._conectar() as conn:
            cur = conn.cursor()
            if filtro:
                cur.execute("SELECT * FROM clientes WHERE nome LIKE ? ORDER BY nome",
                            (f"%{filtro}%",))
            else:
                cur.execute("SELECT * FROM clientes ORDER BY nome")
            return [dict(r) for r in cur.fetchall()]

    def buscar_cliente(self, nome):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM clientes WHERE nome=?", (nome,))
            row = cur.fetchone()
            return dict(row) if row else None

    def atualizar_limite_cliente(self, nome, novo_limite):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE clientes SET limite=? WHERE nome=?",
                        (novo_limite, nome))

    def excluir_cliente(self, cliente_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM clientes WHERE id=?", (cliente_id,))

    def saldo_devedor_cliente(self, nome):
        """Soma os fiados pendentes do cliente."""
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""SELECT COALESCE(SUM(valor), 0) FROM fiados
                           WHERE cliente = ? AND pago = 0""", (nome,))
            return cur.fetchone()[0]

    def limite_disponivel_cliente(self, nome):
        """Retorna (limite, devedor, disponivel)."""
        cli = self.buscar_cliente(nome)
        limite = cli["limite"] if cli else 0
        devedor = self.saldo_devedor_cliente(nome)
        return limite, devedor, limite - devedor

    # =====================================================
    # PEDIDOS DO CLIENTE (totem)
    # =====================================================
    def criar_pedido_cliente(self, cliente, itens_texto, total):
        data = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("""INSERT INTO pedidos_cliente
                (cliente, itens, total, status, data)
                VALUES (?, ?, ?, 'aguardando_pagamento', ?)""",
                (cliente, itens_texto, total, data))
            return cur.lastrowid

    def listar_pedidos_cliente(self, nome=None):
        with self._conectar() as conn:
            cur = conn.cursor()
            if nome:
                cur.execute("SELECT * FROM pedidos_cliente WHERE cliente=? ORDER BY id DESC",
                            (nome,))
            else:
                cur.execute("SELECT * FROM pedidos_cliente ORDER BY id DESC")
            return [dict(r) for r in cur.fetchall()]

    def marcar_pedido_pago(self, pedido_id):
        with self._conectar() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE pedidos_cliente SET status='pago' WHERE id=?", (pedido_id,))