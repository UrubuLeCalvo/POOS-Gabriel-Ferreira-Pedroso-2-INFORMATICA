def _svg(cor, path, size=24):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}"
    viewBox="0 0 24 24" fill="none" stroke="{cor}" stroke-width="2"
    stroke-linecap="round" stroke-linejoin="round">{path}</svg>'''


def icone_home(cor="#2d3436", size=24):
    return _svg(cor, '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>', size)


def icone_produtos(cor="#2d3436", size=24):
    return _svg(cor, '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>', size)


def icone_vendas(cor="#2d3436", size=24):
    return _svg(cor, '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>', size)


def icone_historico(cor="#2d3436", size=24):
    return _svg(cor, '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>', size)


def icone_dinheiro(cor="#2d3436", size=24):
    return _svg(cor, '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>', size)


def icone_pix(cor="#2d3436", size=24):
    return _svg(cor, '<path d="M12 2v20M2 12h20M5.5 5.5l13 13M18.5 5.5l-13 13"/>', size)


def icone_sol(cor="#f39c12", size=20):
    return _svg(cor, '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>', size)


def icone_lua(cor="#636e72", size=20):
    return _svg(cor, '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>', size)