import json
import os
import socket


ARQUIVO_CONFIG = os.path.join(os.path.dirname(__file__), "config.json")

PADRAO = {
    "pix_chave":  "",
    "pix_nome":   "MINHA EMPRESA",
    "pix_cidade": "SAO PAULO",
    "nome_loja":  "Sistema de Vendas",
}


def carregar_config():
    if not os.path.exists(ARQUIVO_CONFIG):
        salvar_config(PADRAO)
        return dict(PADRAO)
    try:
        with open(ARQUIVO_CONFIG, "r", encoding="utf-8") as f:
            dados = json.load(f)
        for k, v in PADRAO.items():
            dados.setdefault(k, v)
        return dados
    except Exception:
        return dict(PADRAO)


def salvar_config(dados: dict):
    with open(ARQUIVO_CONFIG, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=4)


def pix_configurado() -> bool:
    cfg = carregar_config()
    return bool(cfg.get("pix_chave", "").strip())


def meu_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"