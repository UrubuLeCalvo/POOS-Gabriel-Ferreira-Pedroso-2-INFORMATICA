import os
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QPainter, QColor, QFont, QBrush


PASTA_IMAGENS = "imagens_produtos"


TIPOS = {
    "refri":       ("\U0001F964", "#e74c3c"),
    "suco":        ("\U0001F9C3", "#e67e22"),
    "croissant":   ("\U0001F950", "#f39c12"),
    "risole":      ("\U0001F95F", "#e67e22"),
    "hamburguer":  ("\U0001F354", "#c0392b"),
    "enroladinho": ("\U0001F32F", "#d35400"),
    "pao":         ("\U0001F9C0", "#f1c40f"),
    "esfiha":      ("\U0001F958", "#d35400"),
    "coxinha":     ("\U0001F357", "#e67e22"),
    "caldo":       ("\U0001F372", "#16a085"),
    "espeto":      ("\U0001F362", "#8e44ad"),
    "prato":       ("\U0001F35B", "#c0392b"),
    "gelado":      ("\U0001F368", "#3498db"),
    "geral":       ("\U0001F37D", "#95a5a6"),
}


def garantir_imagens():
    os.makedirs(PASTA_IMAGENS, exist_ok=True)
    for tipo, (emoji, cor) in TIPOS.items():
        caminho = os.path.join(PASTA_IMAGENS, f"{tipo}.png")
        if os.path.exists(caminho):
            continue
        _gerar_png(emoji, cor, caminho)


def _gerar_png(emoji: str, cor_fundo: str, caminho: str, tamanho: int = 220):
    pixmap = QPixmap(tamanho, tamanho)
    pixmap.fill(Qt.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)

    painter.setBrush(QBrush(QColor(cor_fundo)))
    painter.setPen(Qt.NoPen)
    painter.drawRoundedRect(0, 0, tamanho, tamanho, 24, 24)

    painter.setPen(QColor("white"))
    fonte = QFont("Segoe UI Emoji", int(tamanho * 0.45))
    painter.setFont(fonte)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, emoji)

    painter.end()
    pixmap.save(caminho, "PNG")


def caminho_imagem(tipo: str) -> str:
    if tipo in TIPOS:
        return os.path.join(PASTA_IMAGENS, f"{tipo}.png")
    return os.path.join(PASTA_IMAGENS, "geral.png")