# pagamento_pix.py
import os
from pixcore import PixData, Pix

def gerar_pix(valor: float, nome_recebedor: str, cidade_recebedor: str, chave_pix: str, caminho_qr_code: str):
    """
    Gera o payload do Pix (Copia e Cola) e salva a imagem do QR Code.

    Retorna:
        payload (str): O texto "Copia e Cola" para pagamento manual.
    """
    try:
        # 1. Define os dados da cobrança
        dados_pix = PixData(
            recebedor_nome=nome_recebedor,
            recebedor_cidade=cidade_recebedor,
            pix_key=chave_pix,
            valor=valor,
            transacao_id=f"VENDA_{valor:.2f}".replace('.', '') # Exemplo de ID único
        )

        # 2. Cria o gerador do Pix
        gerador = Pix(dados_pix)

        # 3. Gera e salva a imagem do QR Code
        gerador.save_qrcode(caminho_qr_code)

        # 4. Gera o payload (Copia e Cola)
        payload = gerador.payload()

        return payload

    except Exception as e:
        print(f"Erro ao gerar Pix: {e}")
        return None